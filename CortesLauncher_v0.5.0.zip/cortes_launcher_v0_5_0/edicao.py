#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
edicao.py (v1) - Estilo "edit" para os cortes: efeitos na batida, montagem rapida,
texto neon e color grade. Usado pelo cortes.py quando o estilo nao e "limpo".

Tudo offline, so com FFmpeg + numpy (sem IA):
  - batidas: se voce escolher uma musica, o app acha o ritmo e o trecho mais forte dela;
    sem musica, usa os impactos do proprio audio do jogo (tiros, explosoes, batidas).
  - efeitos na batida: zoom "soco", tremida, flash, glitch de cor.
  - montagem: divide o corte em fatias no ritmo e fica so com as de mais acao.
  - texto: frases suas, em neon com brilho (ou branco com contorno), entrando na batida.
  - visual: color grade, brilho (bloom), vinheta e granulacao.
"""
import math
import os
import re
import shutil
import tempfile
from pathlib import Path

import numpy as np

import cortes as C

ESTILOS = ("limpo", "edit", "montagem")

# paleta de cada visual: cores do texto/brilho + ajuste de cor
VISUAIS = {
    "neon": dict(
        nome="Neon", cores=["ff3df0", "46b4ff", "b455ff", "ff3d7a"],
        eq="contrast=1.14:saturation=1.45:gamma=0.94",
        bal="rs=0.06:gs=-0.02:bs=0.10:rm=0.04:bm=0.07:rh=0.05:bh=0.04", grao=7, vinheta=True),
    "sangue": dict(
        nome="Sangue", cores=["ff2a2a", "ff7a2a", "ffffff", "ff2a6a"],
        eq="contrast=1.18:saturation=1.30:gamma=0.92",
        bal="rs=0.08:gs=-0.04:bs=-0.06:rm=0.07:bm=-0.05:rh=0.06:bh=-0.04", grao=8, vinheta=True),
    "cinema": dict(
        nome="Cinema", cores=["ffffff", "ffe1b0", "ffffff", "b0d8ff"],
        eq="contrast=1.10:saturation=1.12:gamma=0.97",
        bal="rs=-0.04:bs=0.05:rh=0.05:bh=-0.04", grao=5, vinheta=True),
}

# nivel de cada estilo/ritmo
FATIA_BASE = 1.2      # segundos por fatia na montagem (ajustado para a batida)
MANTER = 0.65         # fracao do corte que a montagem mantem (as fatias de mais acao)
MAX_EVENTOS = 26      # limite de impactos usados nas expressoes (o grafo precisa ser curto)

FONTES_WIN = ["impact.ttf", "bahnschrift.ttf", "arialbd.ttf", "segoeuib.ttf", "arial.ttf"]
FONTES_OUTROS = [
    "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "/Library/Fonts/Arial Bold.ttf",
]


# ----------------------------------------------------------------------------
# Utilidades
# ----------------------------------------------------------------------------
def achar_fonte():
    """Caminho de uma fonte negrito do sistema (ou None)."""
    cands = []
    windir = os.environ.get("WINDIR") or os.environ.get("SystemRoot")
    if windir:
        cands += [Path(windir) / "Fonts" / f for f in FONTES_WIN]
    cands += [Path(p) for p in FONTES_OUTROS]
    for p in cands:
        if p.is_file():
            return p
    return None


def _num(x, casas=3):
    s = f"{x:.{casas}f}".rstrip("0").rstrip(".")
    return s if s not in ("", "-0") else "0"


def _decodificar_mono(path, ini, dur, sr=11025):
    """Audio mono (float32) de [ini, ini+dur] do arquivo. None se nao tiver audio."""
    cmd = ["ffmpeg", "-v", "error", "-ss", f"{max(0.0, ini):.2f}", "-t", f"{dur:.2f}", "-i", str(path),
           "-vn", "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"]
    raw = C._run(cmd, capture_output=True).stdout
    if len(raw) < sr:
        return None
    return np.frombuffer(raw[: len(raw) // 2 * 2], dtype=np.int16).astype(np.float32) / 32768.0


def _onsets(a, sr=11025, hop=256):
    """Curva de 'impacto' (subida de energia) por janela de hop amostras. Retorna (curva, fps)."""
    n = len(a) // hop
    if n < 8:
        return None, sr / hop
    e = np.sqrt((a[: n * hop].reshape(n, hop) ** 2).mean(axis=1))
    on = np.maximum(0.0, np.diff(np.log1p(e * 60.0), prepend=0.0))
    on = np.maximum(0.0, on - np.convolve(on, np.ones(24) / 24.0, mode="same"))
    return on.astype(np.float32), sr / hop


# ----------------------------------------------------------------------------
# Batidas e impactos
# ----------------------------------------------------------------------------
def analisar_musica(path, dur_saida):
    """Acha o ritmo da musica e o melhor trecho (o mais forte) para 'dur_saida' segundos.
    Retorna dict(ss, periodo, t0, forca) com t0 = primeira batida (em s, a partir de ss)."""
    total_max = 420.0
    a = _decodificar_mono(path, 0, total_max)
    if a is None:
        raise C.ErroCortes("Nao consegui ler o audio da musica escolhida.")
    sr = 11025
    on, fps = _onsets(a, sr)
    if on is None:
        raise C.ErroCortes("A musica e curta demais.")
    # tempo (autocorrelacao do onset), dobrando/metade para ficar entre 80 e 170 BPM
    x = on - on.mean()
    ac = np.correlate(x[: min(len(x), int(fps * 90))], x[: min(len(x), int(fps * 90))], "full")
    ac = ac[len(ac) // 2:]
    lo, hi = int(fps * 60 / 175), int(fps * 60 / 70)
    hi = min(hi, len(ac) - 1)
    if hi <= lo:
        raise C.ErroCortes("A musica e curta demais.")
    lag = lo + int(np.argmax(ac[lo:hi]))
    bpm = 60.0 * fps / lag
    while bpm < 80:
        bpm *= 2
    while bpm > 170:
        bpm /= 2
    periodo = 60.0 / bpm
    # melhor janela: maior energia media (o "drop"), comecando numa batida
    win = int(min(dur_saida, len(a) / sr - 1) * fps)
    env = np.convolve(on, np.ones(max(1, win)) / max(1, win), mode="valid")
    cand = np.arange(len(env))
    # evita os primeiros 5 s (intro) quando a musica e longa
    if len(a) / sr > dur_saida + 25:
        cand = cand[int(5 * fps):]
    cand = cand[: max(1, len(cand))]
    melhor_i = int(cand[np.argmax(env[cand])]) if len(cand) else 0
    ss_aprox = melhor_i / fps
    # refina periodo e fase: procura a grade (comb) que mais casa com os impactos do trecho escolhido
    ini_i = int(ss_aprox * fps)
    seg = on[ini_i: ini_i + int(min(dur_saida, 30) * fps)]
    seg = np.convolve(seg, [0.25, 0.5, 0.25], mode="same")
    melhor = (-1.0, periodo, 0.0)
    for P in np.linspace(periodo * 0.95, periodo * 1.05, 101):
        pf = P * fps
        for fase in np.arange(0.0, pf, 0.5):
            pos = np.arange(fase, len(seg) - 1.5, pf)
            if len(pos) == 0:
                continue
            i = pos.astype(int)
            fr = pos - i
            sc = float(((1 - fr) * seg[i] + fr * seg[np.minimum(i + 1, len(seg) - 1)]).sum())
            if sc > melhor[0]:
                melhor = (sc, float(P), float(fase))
    _sc, periodo, fase = melhor
    # o trecho comeca exatamente numa batida
    ss = ss_aprox + fase / fps
    return dict(ss=max(0.0, ss), periodo=periodo, t0=0.0, bpm=60.0 / periodo,
                forca=float(env[melhor_i]) if len(env) else 0.0)


def impactos_audio(path, ini, dur, n_max=MAX_EVENTOS, folga=0.35):
    """Instantes (relativos a 'ini') dos maiores impactos do audio do jogo."""
    a = _decodificar_mono(path, ini, dur)
    if a is None:
        return []
    on, fps = _onsets(a)
    if on is None:
        return []
    lim = max(float(np.percentile(on, 90)), 1e-6)
    picos = []
    for i in range(1, len(on) - 1):
        if on[i] >= lim and on[i] >= on[i - 1] and on[i] > on[i + 1]:
            picos.append((float(on[i]), i / fps))
    picos.sort(reverse=True)
    esc = []
    for f, t in picos:
        if all(abs(t - u) >= folga for _f, u in esc):
            esc.append((f, t))
        if len(esc) >= n_max:
            break
    return sorted(t for _f, t in esc)


# ----------------------------------------------------------------------------
# Envoltorias de tempo (expressoes do FFmpeg)
# ----------------------------------------------------------------------------
class Pulso:
    """Impulsos no tempo: grade de batidas (compacta) ou lista de instantes."""

    def __init__(self, grade=None, eventos=None):
        self.grade = grade          # (periodo, t0)
        self.eventos = sorted(eventos or [])[:MAX_EVENTOS]

    def vazio(self):
        return self.grade is None and not self.eventos

    def expr(self, decaimento, cada=1, desloc=0):
        """exp(-d * tempo desde o ultimo impulso). 'cada' = usa 1 a cada N batidas (so com grade)."""
        d = _num(decaimento, 2)
        if self.grade is not None:
            p, t0 = self.grade
            P = p * cada
            T0 = t0 + desloc * p
            return f"exp(-{d}*mod(t-{_num(T0, 4)}+{_num(P * 4, 4)},{_num(P, 4)}))"
        evs = self.eventos[::cada] if cada > 1 else self.eventos
        if not evs:
            return "0"
        termos = "+".join(f"if(gte(t,{_num(e)}),exp(-{d}*(t-{_num(e)})),0)" for e in evs)
        return f"min(1,{termos})"


# ----------------------------------------------------------------------------
# Plano da edicao
# ----------------------------------------------------------------------------
def fatias_montagem(corte, score, periodo, manter=MANTER):
    """Divide [ini, fim] em fatias no ritmo e mantem as de mais acao (em ordem)."""
    ini, fim = corte["ini"], corte["fim"]
    dur = fim - ini
    if periodo:
        k = max(1, int(round(FATIA_BASE / periodo)))
        L = k * periodo
    else:
        L = FATIA_BASE
    n = max(1, int(dur // L))
    fat = [(ini + i * L, L) for i in range(n)]
    if score is None or n <= 2:
        return fat
    notas = [C.nota_trecho(score, a, a + d) for a, d in fat]
    quantas = max(2, int(round(n * manter)))
    top = set(sorted(range(n), key=lambda i: notas[i], reverse=True)[:quantas])
    return [f for i, f in enumerate(fat) if i in top]


def _pad_texto_posicao(tam):
    return int(tam)


def _escrever_frases(tmp, frases, dur, pulso_grade, fatias_t, cores, fonte_ok):
    """Cria os arquivos de texto e devolve lista de (arquivo, ini, fim, cor)."""
    frases = [f.strip() for f in frases if f and f.strip()]
    if not frases or not fonte_ok:
        return []
    n = len(frases)
    # cada frase aparece numa batida; a primeira entra cedo
    if pulso_grade is not None:
        p, t0 = pulso_grade
        passo = p * max(1, round((dur / n) / p))
    else:
        passo = dur / n
    out = []
    for i, f in enumerate(frases):
        a = t0 + i * passo if pulso_grade is not None else i * passo
        a = min(a, max(0.0, dur - 0.8))
        b = a + passo if i < n - 1 else dur - 0.15
        arq = f"txt{i}.txt"
        (tmp / arq).write_text(f.upper(), encoding="utf-8")
        out.append((arq, a, min(b, dur), cores[i % len(cores)]))
    return out


def montar_grafo_edit(n_in, dims, q, fps, dur_saida, pulso, textos, visual, tela_cheia,
                      estilo_texto, flash_cada, tem_fonte, qual_nome):
    """Filtergraph do estilo edit. n_in = numero de entradas de video (fatias), concatenadas."""
    W, H = dims
    ow, oh = C.tamanho_saida(q["larg"])
    V = VISUAIS[visual]
    leve = qual_nome == "rapido"
    g = []
    # 1) fatias -> concat
    for i in range(n_in):
        g.append(f"[{i}:v]fps={fps},setpts=PTS-STARTPTS[s{i}]")
    if n_in > 1:
        g.append("".join(f"[s{i}]" for i in range(n_in)) + f"concat=n={n_in}:v=1:a=0[cat]")
    else:
        g.append("[s0]null[cat]")

    z = pulso.expr(7.0)          # soco de zoom
    amp_z = 0.075 if not leve else 0.06
    # 2) enquadramento (com fundo desfocado ou tela cheia) + zoom na batida
    if tela_cheia:
        g.append(
            f"[cat]scale=w='trunc((max({ow}/iw,{oh}/ih)*iw)*(1+{amp_z}*{z})/2)*2'"
            f":h='trunc((max({ow}/iw,{oh}/ih)*ih)*(1+{amp_z}*{z})/2)*2':eval=frame[fg]")
        sx = f"(W-w)/2+{_num(ow * 0.012)}*{pulso.expr(9.0)}*sin(t*97)"
        sy = f"(H-h)/2+{_num(oh * 0.008)}*{pulso.expr(9.0)}*cos(t*83)"
        g.append(f"color=c=black:s={ow}x{oh}:r={fps}[bgc]")
        g.append(f"[bgc][fg]overlay=x='{sx}':y='{sy}':shortest=1,setsar=1[comp]")
    else:
        if W * 16 >= H * 9:
            fw, fh = float(ow), ow * H / W
        else:
            fw, fh = oh * W / H, float(oh)
        g.append("[cat]split=2[bg][fg]")
        g.append("[bg]scale=216:384:force_original_aspect_ratio=increase,crop=216:384,"
                 f"boxblur=8:2,scale={ow}:{oh},eq=brightness=-0.12[b]")
        g.append(f"[fg]scale=w='trunc({_num(fw, 2)}*(1+{amp_z}*{z})/2)*2'"
                 f":h='trunc({_num(fh, 2)}*(1+{amp_z}*{z})/2)*2':eval=frame[f]")
        sx = f"(W-w)/2+{_num(ow * 0.012)}*{pulso.expr(9.0)}*sin(t*97)"
        sy = f"(H-h)/2+{_num(oh * 0.008)}*{pulso.expr(9.0)}*cos(t*83)"
        g.append(f"[b][f]overlay=x='{sx}':y='{sy}':shortest=1,setsar=1[comp]")

    # 3) color grade + brilho + vinheta + granulacao + flash na batida
    flash = pulso.expr(14.0, cada=flash_cada)
    cadeia = [f"eq=contrast={V['eq'].split('contrast=')[1].split(':')[0]}"
              f":saturation={V['eq'].split('saturation=')[1].split(':')[0]}"
              f":gamma={V['eq'].split('gamma=')[1]}",
              f"colorbalance={V['bal']}",
              f"eq=brightness='0.16*{flash}':eval=frame"]
    if V["vinheta"]:
        cadeia.append("vignette=PI/5")
    g.append("[comp]" + ",".join(cadeia) + "[grd]")
    if not leve:
        bw, bh = max(2, ow // 8 // 2 * 2), max(2, oh // 8 // 2 * 2)
        g.append("[grd]split=2[g1][g2]")
        g.append(f"[g2]scale={bw}:{bh}:flags=fast_bilinear,gblur=sigma=3,scale={ow}:{oh}:flags=bilinear,"
                 "eq=brightness=-0.04,format=gbrp[gbr]")
        g.append("[g1]format=gbrp[g1r]")
        g.append("[g1r][gbr]blend=all_mode=screen:all_opacity=0.38[bl]")
        g.append(f"[bl]noise=alls={V['grao']}:allf=t,format=yuv420p[vfx]")
    else:
        g.append("[grd]format=yuv420p[vfx]")

    # 4) glitch de cor (so quando a batida e forte) + texto
    ultimo = "vfx"
    if not leve and (pulso.grade is not None or pulso.eventos):
        gl = pulso.expr(16.0, cada=2 if pulso.grade is not None else 1)
        g.append(f"[vfx]rgbashift=rh=-6:bh=6:enable='gt({gl},0.55)'[vgl]")
        ultimo = "vgl"

    if textos:
        tam = int(ow * 0.095)
        dts = []
        for (arq, a, b, cor) in textos:
            alpha = (f"if(lt(t,{_num(a)}),0,if(lt(t,{_num(a + 0.12)}),(t-{_num(a)})/0.12,"
                     f"if(gt(t,{_num(b - 0.1)}),max(0,({_num(b)}-t)/0.1),1)))")
            yy = f"(h*0.70)-{_num(oh * 0.03)}*exp(-14*max(0,t-{_num(a)}))"
            if estilo_texto == "neon":
                dts.append(f"drawtext=fontfile=fonte.ttf:textfile={arq}:fontsize={tam}:fontcolor=white"
                           f":x=(w-text_w)/2:y='{yy}':alpha='{alpha}':borderw={max(3, int(tam * 0.055))}"
                           f":bordercolor=0x{cor}")
            else:
                dts.append(f"drawtext=fontfile=fonte.ttf:textfile={arq}:fontsize={int(tam * 0.8)}:fontcolor=white"
                           f":x=(w-text_w)/2:y='{yy}':alpha='{alpha}':borderw={max(3, int(tam * 0.07))}"
                           f":bordercolor=black")
        if estilo_texto == "neon":
            # uma camada preta com todos os textos -> brilho (blur em baixa resolucao) -> tela (screen)
            gw, gh = max(2, ow // 4 // 2 * 2), max(2, oh // 4 // 2 * 2)
            g.append(f"color=c=black:s={ow}x{oh}:r={fps}:d={_num(dur_saida + 1, 2)}[tb]")
            g.append("[tb]" + ",".join(dts) + ",format=gbrp,split=2[ta][tc]")
            g.append(f"[tc]scale={gw}:{gh}:flags=fast_bilinear,gblur=sigma=5,scale={ow}:{oh}:flags=bilinear[td]")
            g.append("[ta][td]blend=all_mode=addition[te]")
            g.append(f"[{ultimo}]format=gbrp[vr]")
            g.append("[vr][te]blend=all_mode=screen,format=yuv420p[vt]")
        else:
            g.append(f"[{ultimo}]" + ",".join(dts) + "[vt]")
        ultimo = "vt"

    # 5) entrada/saida rapidas
    g.append(f"[{ultimo}]fade=t=in:st=0:d=0.15,fade=t=out:st={_num(max(0.0, dur_saida - 0.25))}:d=0.25[v]")
    return ";".join(g)


# ----------------------------------------------------------------------------
# Renderizacao
# ----------------------------------------------------------------------------
def _tem_audio(src):
    try:
        return bool(C._probe(src, "stream=codec_type", "a:0"))
    except Exception:
        return False


def _fps_saida(src, qual_nome):
    try:
        num, den = C._probe(src, "stream=r_frame_rate", "v:0").split("/")
        f = float(num) / float(den)
    except Exception:
        f = 30.0
    return 60 if (qual_nome == "alta" and f >= 50) else 30


def renderizar_edit(src, corte, saida, args, checar=None, progresso=None):
    """Renderiza um corte no estilo edit/montagem. Mesmo contrato do cortes.renderizar."""
    src, saida = Path(src).resolve(), Path(saida).resolve()
    estilo = getattr(args, "estilo", "edit")
    visual = getattr(args, "visual", "neon")
    if visual not in VISUAIS:
        visual = "neon"
    qual_nome = getattr(args, "qualidade", "normal")
    q = C.QUALIDADES.get(qual_nome, C.QUALIDADES["normal"])
    musica = getattr(args, "musica", "") or ""
    musica = musica if musica and Path(musica).is_file() else ""
    frases = list(getattr(args, "frases", []) or [])
    tela_cheia = bool(getattr(args, "tela_cheia", False))
    nvenc = bool(getattr(args, "nvenc", False))
    ini, fim = corte["ini"], corte["fim"]
    dur_janela = fim - ini
    dims = C.dimensoes(src)
    fps = _fps_saida(src, qual_nome)

    # ritmo: musica (grade) ou impactos do jogo
    mus = None
    if musica:
        try:
            mus = analisar_musica(musica, dur_janela)
            C.log(f"      musica: ~{mus['bpm']:.0f} BPM")
        except C.ErroCortes as e:
            C.log(f"      {e} Seguindo com o audio do jogo.")
    periodo = mus["periodo"] if mus else None

    # fatias
    if estilo == "montagem":
        fatias = fatias_montagem(corte, corte.get("score"), periodo)
    else:
        fatias = [(ini, dur_janela)]
    dur_saida = sum(d for _a, d in fatias)
    if mus and dur_saida > 0:
        pass

    # pulso (impactos no tempo da saida)
    if mus:
        pulso = Pulso(grade=(mus["periodo"], mus["t0"]))
    else:
        ev_janela = impactos_audio(src, ini, dur_janela)
        eventos, acum = [], 0.0
        for a, d in fatias:
            eventos += [acum + (t - (a - ini)) for t in ev_janela if a - ini <= t < a - ini + d]
            if estilo == "montagem":
                eventos.append(acum)  # cada corte de fatia e um impacto
            acum += d
        eventos = sorted(set(round(e, 3) for e in eventos))
        # tira os muito colados
        lim = []
        for e in eventos:
            if not lim or e - lim[-1] >= 0.3:
                lim.append(e)
        pulso = Pulso(eventos=lim)

    tmp = Path(tempfile.mkdtemp(prefix="cortes_edit_"))
    try:
        fonte = achar_fonte()
        tem_fonte = fonte is not None
        if tem_fonte:
            shutil.copyfile(fonte, tmp / "fonte.ttf")
        elif frases:
            C.log("      nao achei uma fonte do sistema; o texto sera ignorado.")
        visu = VISUAIS[visual]
        textos = _escrever_frases(tmp, frases, dur_saida, pulso.grade, None, visu["cores"], tem_fonte)
        estilo_texto = "neon" if visual != "cinema" else "branco"
        flash_cada = 4 if pulso.grade is not None else 1
        grafo = montar_grafo_edit(len(fatias), dims, q, fps, dur_saida, pulso, textos, visual,
                                  tela_cheia, estilo_texto, flash_cada, tem_fonte, qual_nome)

        cmd = ["ffmpeg", "-y", "-v", "error"]
        for a, d in fatias:
            cmd += ["-ss", f"{a:.3f}", "-t", f"{d:.3f}", "-i", str(src)]
        n = len(fatias)
        saida_a = None
        tem_a = _tem_audio(src)
        fade_fim = _num(max(0, dur_saida - 0.6))
        if mus:
            cmd += ["-ss", f"{mus['ss']:.3f}", "-t", f"{dur_saida + 0.5:.3f}", "-i", musica]
            ai = n
            grafo += f";[{ai}:a]afade=t=in:d=0.05,afade=t=out:st={fade_fim}:d=0.6[m]"
            if tem_a and n == 1:  # som do jogo baixinho por baixo da musica
                grafo += ";[0:a]volume=0.22[ga];[m][ga]amix=inputs=2:duration=first:normalize=0[a]"
            else:
                grafo += ";[m]anull[a]"
            saida_a = "[a]"
        elif tem_a:
            if n == 1:
                grafo += ";[0:a]afade=t=in:d=0.05,afade=t=out:st=" + _num(max(0, dur_saida - 0.25)) + ":d=0.25[a]"
            else:
                partes = [f"[{i}:a]afade=t=in:d=0.02,afade=t=out:st={_num(max(0, fatias[i][1] - 0.02))}:d=0.02[a{i}]"
                          for i in range(n)]
                grafo += (";" + ";".join(partes) + ";" + "".join(f"[a{i}]" for i in range(n))
                          + f"concat=n={n}:v=0:a=1[a]")
            saida_a = "[a]"

        cmd += ["-filter_complex", grafo, "-map", "[v]"] + (["-map", saida_a] if saida_a else ["-an"])
        if nvenc:
            cmd_v = ["-c:v", "h264_nvenc", "-preset", q["nv"], "-cq", str(q["cq"])]
        else:
            cmd_v = ["-c:v", "libx264", "-preset", q["preset"], "-crf", str(q["crf"])]
        cmd += cmd_v + ["-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
                        "-t", f"{dur_saida:.3f}", "-movflags", "+faststart", str(saida)]
        try:
            C._ffmpeg_cancelavel(cmd, checar, saida, dur_saida, progresso, cwd=str(tmp))
        except C.ErroCortes:
            if not nvenc:
                raise
            C.log("      a placa NVIDIA nao respondeu; usando o processador neste corte.")
            cmd = [c for c in cmd]
            i = cmd.index("h264_nvenc")
            cmd[i - 1: i + 5] = ["-c:v", "libx264", "-preset", q["preset"], "-crf", str(q["crf"])]
            C._ffmpeg_cancelavel(cmd, checar, saida, dur_saida, progresso, cwd=str(tmp))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    corte["fim_real"] = corte["ini"] + dur_saida
    return dur_saida
