# -*- coding: utf-8 -*-
"""
baixador.py - baixa lives e videos por link usando o yt-dlp (programa externo).

Sem interface: o launcher chama baixar_por_link() numa thread e recebe progresso
por funcoes de retorno. Nada aqui depende de tkinter.

Como funciona:
  1. Na 1a vez baixa o yt-dlp.exe (~20 MB) para a pasta do app e confere o hash
     SHA-256 publicado junto da versao. Depois, se tiver mais de 3 dias, atualiza
     sozinho (o YouTube muda toda hora e o yt-dlp precisa acompanhar).
  2. Baixa o video em ate 1080p (preferindo H.264) como MP4.
  3. Se der erro tipico de "site mudou", atualiza o yt-dlp e tenta de novo, 1 vez.
"""
import hashlib
import os
import re
import shutil
import subprocess
import threading
import time
import urllib.request
from pathlib import Path

import cortes
from cortes import Cancelado, ErroCortes

YTDLP_URL = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe"
YTDLP_SUMS_URL = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/SHA2-256SUMS"
IDADE_MAX_DIAS = 3
MARCA = "CORTES_ARQUIVO:"  # prefixo da linha em que o yt-dlp informa o arquivo final
MIN_LIVRE_GB = 1.0

RE_PROG = re.compile(r"^\[download\]\s+(\d+(?:\.\d+)?)%")
RE_ETA = re.compile(r"ETA\s+(\S+)")
RE_VEL = re.compile(r"\sat\s+(\S+/s)")

# Mensagens do yt-dlp que indicam "o site mudou": vale atualizar o yt-dlp e tentar de novo.
PADROES_ATUALIZAR = re.compile(
    r"Unable to extract|Failed to extract|nsig extraction|HTTP Error 403|"
    r"unable to download video data|Requested format is not available|"
    r"Did not get any data blocks", re.I)


class ErroAtualizar(ErroCortes):
    """Erro que costuma sumir com um yt-dlp mais novo."""


_ATIVO = None  # processo do yt-dlp em andamento (para fechar o app sem deixar sobra)


# ----------------------------------------------------------------------------
# Instalacao / atualizacao do yt-dlp
# ----------------------------------------------------------------------------
def ytdlp_exe(pasta):
    return Path(pasta) / "yt-dlp.exe"


def _baixar_bytes(url, ua, timeout=30, progresso=None):
    req = urllib.request.Request(url, headers={"User-Agent": ua})
    partes, feito = [], 0
    with urllib.request.urlopen(req, timeout=timeout) as r:
        total = int(r.headers.get("Content-Length") or 0)
        while True:
            bloco = r.read(256 * 1024)
            if not bloco:
                break
            partes.append(bloco)
            feito += len(bloco)
            if progresso:
                progresso(feito / total if total else None, feito)
    return b"".join(partes)


def hash_esperado(texto_sums, nome="yt-dlp.exe"):
    """Acha o SHA-256 de 'nome' no arquivo SHA2-256SUMS (linhas '<hash>  <arquivo>')."""
    for linha in texto_sums.splitlines():
        partes = linha.split()
        if len(partes) >= 2 and partes[-1].lstrip("*") == nome:
            return partes[0].lower()
    return None


def instalar_ytdlp(pasta, ua, progresso=None):
    pasta = Path(pasta)
    pasta.mkdir(parents=True, exist_ok=True)
    dados = _baixar_bytes(YTDLP_URL, ua, progresso=progresso)
    sums = _baixar_bytes(YTDLP_SUMS_URL, ua).decode("utf-8", errors="replace")
    esperado = hash_esperado(sums)
    if not esperado or hashlib.sha256(dados).hexdigest() != esperado:
        raise ErroCortes("O yt-dlp baixado não passou na verificação de integridade. Tente de novo.")
    exe = ytdlp_exe(pasta)
    novo = Path(str(exe) + ".new")
    novo.write_bytes(dados)
    os.replace(novo, exe)


def garantir_ytdlp(pasta, ua, progresso=None, forcar=False):
    """Devolve (exe, atualizou). Baixa se nao existe, se esta velho ou se 'forcar'."""
    exe = ytdlp_exe(pasta)
    velho = (not exe.exists()) or (time.time() - exe.stat().st_mtime > IDADE_MAX_DIAS * 86400)
    if not (forcar or velho):
        return exe, False
    try:
        instalar_ytdlp(pasta, ua, progresso)
    except Exception as e:
        if exe.exists() and not forcar:  # tem uma versao antiga: segue com ela
            return exe, False
        if isinstance(e, ErroCortes):
            raise
        raise ErroCortes(
            f"Não consegui baixar o yt-dlp ({e}). "
            "Verifique sua internet (ou antivírus/firewall) e tente de novo.")
    return exe, True


# ----------------------------------------------------------------------------
# Link, comando e erros
# ----------------------------------------------------------------------------
def normalizar_url(txt):
    t = (txt or "").strip()
    if not t or re.search(r"\s", t):
        raise ErroCortes("Cole o link completo da live ou do vídeo.")
    if not re.match(r"^https?://", t, re.I):
        if "." not in t:
            raise ErroCortes("Esse texto não parece um link. Cole o endereço completo da live ou do vídeo.")
        t = "https://" + t
    return t


def montar_cmd(exe, url, pasta_saida, ffmpeg_dir=None):
    prefixo = [str(exe)] if not isinstance(exe, (list, tuple)) else [str(x) for x in exe]
    cmd = prefixo + [
        "--no-playlist", "--playlist-items", "1",
        "--match-filters", "!is_live",              # live ainda no ar: nao baixa (ficaria horas gravando)
        "-f", "bv*+ba/b", "-S", "res:1080,vcodec:h264,acodec:m4a",
        "--merge-output-format", "mp4",
        "-N", "4", "--no-mtime", "--restrict-filenames",
        "--no-quiet", "--newline", "--progress",   # --print sozinho ligaria o modo silencioso
        "-P", str(pasta_saida), "-o", "%(title).60s_%(id)s.%(ext)s",
        "--print", f"after_move:{MARCA}%(filepath)s",
    ]
    if ffmpeg_dir and (Path(ffmpeg_dir) / "ffmpeg.exe").exists():
        cmd += ["--ffmpeg-location", str(ffmpeg_dir)]
    cmd.append(url)
    return cmd


def traduzir_erro(texto):
    """Mensagem amigavel para erros conhecidos; None se nao reconhecer."""
    t = texto or ""
    regras = [
        (r"does not pass filter",
         "Essa live ainda está no ar. Espere ela terminar (e o YouTube terminar de processar) e tente de novo."),
        (r"Premieres in|will begin in|live event will begin",
         "Esse vídeo ou live ainda não começou."),
        (r"confirm your age|age-restricted|inappropriate for some users",
         "Esse vídeo tem restrição de idade e precisa de login, então não dá para baixar por aqui."),
        (r"Private video|members-only|Join this channel|members only",
         "Esse vídeo é privado ou só para membros do canal."),
        (r"Video unavailable|has been removed|This video is not available|account associated.*terminated",
         "Esse vídeo está indisponível ou foi removido."),
        (r"Sign in to confirm|not a bot",
         "O site pediu confirmação de que você não é um robô para esse vídeo. Tente de novo mais tarde ou em outra rede."),
        (r"Unsupported URL|is not a valid URL",
         "Link não reconhecido. Confira se copiou o endereço inteiro do vídeo."),
        (r"getaddrinfo failed|Temporary failure in name resolution|Unable to download webpage|"
         r"Network is unreachable|timed out",
         "Sem conexão com a internet (ou o site não respondeu). Verifique e tente de novo."),
        (r"No space left|Errno 28|not enough space",
         "O disco está cheio. Libere espaço e tente de novo."),
    ]
    for padrao, msg in regras:
        if re.search(padrao, t, re.I):
            return msg
    return None


def _checar_espaco(pasta):
    try:
        Path(pasta).mkdir(parents=True, exist_ok=True)
        livre = shutil.disk_usage(pasta).free / 1e9
    except OSError:
        return
    if livre < MIN_LIVRE_GB:
        raise ErroCortes(f"Pouco espaço em disco ({livre:.1f} GB livres). Libere espaço e tente de novo.")


def _matar(proc):
    """Encerra o yt-dlp. No Windows o .exe cria um processo filho, entao mata a arvore."""
    try:
        if proc.poll() is not None:
            return
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True,
                           stdin=subprocess.DEVNULL, creationflags=cortes.FLAGS)
        else:
            proc.kill()
    except Exception:
        pass


def parar():
    """Chamado ao fechar o app: nao deixa o yt-dlp rodando escondido."""
    if _ATIVO is not None:
        _matar(_ATIVO)


RES_CAMINHO = [
    re.compile(r'Merging formats into "(.+)"'),
    re.compile(r"^\[download\]\s+(.+?)\s+has already been downloaded"),
    re.compile(r"^\[download\]\s+Destination:\s+(.+)$"),
]


def _caminho_do_log(linhas):
    for rx in RES_CAMINHO:
        for linha in reversed(linhas):
            m = rx.search(linha)
            if m:
                p = Path(m.group(1).strip())
                if p.is_file() and p.suffix.lower() in cortes.VIDEO_EXT:
                    return p
    return None


def _achar_novo(pasta, desde):
    achados = []
    for p in Path(pasta).iterdir():
        try:
            if p.is_file() and p.suffix.lower() in cortes.VIDEO_EXT and p.stat().st_mtime >= desde:
                achados.append(p)
        except OSError:
            continue
    return max(achados, key=lambda p: p.stat().st_mtime, default=None)


# ----------------------------------------------------------------------------
# Download
# ----------------------------------------------------------------------------
def baixar_video(url, pasta_saida, exe, ffmpeg_dir=None, progresso=None, log=None, cancelar=None):
    """Roda o yt-dlp e devolve o Path do arquivo. progresso(fracao, eta, velocidade)."""
    global _ATIVO
    pasta_saida = Path(pasta_saida)
    pasta_saida.mkdir(parents=True, exist_ok=True)
    cmd = montar_cmd(exe, url, pasta_saida, ffmpeg_dir)
    kw = dict(stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
              text=True, encoding="utf-8", errors="replace", bufsize=1)
    if cortes.FLAGS:
        kw["creationflags"] = cortes.FLAGS
    inicio = time.time()
    try:
        proc = subprocess.Popen(cmd, **kw)
    except OSError as e:
        raise ErroCortes(f"Não consegui abrir o yt-dlp: {e}")
    _ATIVO = proc

    def vigia():  # cancelamento mesmo quando o yt-dlp esta calado
        if cancelar is None:
            return
        while proc.poll() is None:
            if cancelar.wait(0.3):
                _matar(proc)
                return

    threading.Thread(target=vigia, daemon=True).start()

    caminho, saida, ultimo_t = None, [], 0.0
    try:
        for linha in proc.stdout:
            linha = linha.rstrip()
            if not linha:
                continue
            if linha.startswith(MARCA):
                caminho = Path(linha[len(MARCA):].strip())
                continue
            m = RE_PROG.match(linha)
            if m:
                agora = time.time()
                if progresso and agora - ultimo_t >= 0.25:
                    ultimo_t = agora
                    eta, vel = RE_ETA.search(linha), RE_VEL.search(linha)
                    progresso(float(m.group(1)) / 100.0, eta.group(1) if eta else None,
                              vel.group(1) if vel else None)
                continue
            saida.append(linha)
            if log:
                log(linha)
        proc.wait()
    finally:
        if proc.poll() is None:
            _matar(proc)
            proc.wait()
        _ATIVO = None

    if cancelar is not None and cancelar.is_set():
        raise Cancelado()

    texto = "\n".join(saida)
    if proc.returncode == 0 and (caminho is None or not caminho.is_file()):
        caminho = _caminho_do_log(saida) or _achar_novo(pasta_saida, inicio)
    if caminho is not None and caminho.is_file() and proc.returncode == 0:
        return caminho

    amigavel = traduzir_erro(texto)
    if amigavel:
        raise ErroCortes(amigavel)
    if proc.returncode == 0:  # terminou sem erro e sem arquivo: o unico filtro que usamos e o da live no ar
        raise ErroCortes("Nenhum vídeo foi baixado. Se for uma live, ela pode ainda estar no ar: "
                         "espere terminar e tente de novo.")
    cauda = "\n".join(texto.splitlines()[-4:]) or f"código de saída {proc.returncode}"
    if PADROES_ATUALIZAR.search(texto):
        raise ErroAtualizar(f"O yt-dlp não conseguiu baixar:\n{cauda}")
    raise ErroCortes(f"O yt-dlp não conseguiu baixar:\n{cauda}")


def baixar_por_link(url, pasta_saida, pasta_ytdlp, ffmpeg_dir, ua,
                    progresso=None, log=None, status=None, cancelar=None):
    """Fluxo completo. status(texto, fracao=None) informa as etapas. Devolve o Path do video."""
    def st(t, f=None):
        if status:
            status(t, f)

    def checar():
        if cancelar is not None and cancelar.is_set():
            raise Cancelado()

    url = normalizar_url(url)
    _checar_espaco(pasta_saida)
    checar()
    st("Preparando o yt-dlp...")
    exe, atualizou = garantir_ytdlp(
        pasta_ytdlp, ua, lambda f, feito: st(f"Baixando o yt-dlp... {feito / 1048576:.0f} MB", f))
    checar()
    st("Conectando ao vídeo...")
    ultimo = None
    for tentativa in (1, 2):
        try:
            return baixar_video(url, pasta_saida, exe, ffmpeg_dir, progresso, log, cancelar)
        except ErroAtualizar as e:
            ultimo = e
            if tentativa == 1 and not atualizou:
                st("O yt-dlp está desatualizado. Atualizando...")
                exe, atualizou = garantir_ytdlp(
                    pasta_ytdlp, ua,
                    lambda f, feito: st(f"Baixando o yt-dlp... {feito / 1048576:.0f} MB", f), forcar=True)
                checar()
                st("Tentando de novo...")
            else:
                break
    raise ErroCortes("O site mudou algo e o yt-dlp não conseguiu baixar, mesmo atualizado. "
                     "Tente de novo mais tarde.\n\n" + str(ultimo))
