# -*- coding: utf-8 -*-
"""
visual.py - Tema, animacoes e componentes (desenhados em Canvas) do Cortes Launcher.

Ideia: a janela inteira e UM Canvas animado (Fundo). Os cartoes (Painel) sao desenhados
nele e levam o conteudo em Frames. Tudo que fica "solto" sobre o fundo (titulo, passos,
rodape) e desenhado como item do proprio Canvas, para o fundo animado aparecer atras.

Animacoes sao opcionais (Animador.ligado) e ficam mais leves enquanto o app processa,
para nao competir com o FFmpeg em PC fraco. Se uma animacao der erro, ela se desliga
sozinha e o app continua funcionando.
"""
import base64
import math
import random
import struct
import time
import zlib
from types import SimpleNamespace

import tkinter as tk
from tkinter import font as tkfont

import numpy as np

# ----------------------------------------------------------------------------
# Paleta
# ----------------------------------------------------------------------------
BG = "#120E26"
CARD = "#1B1538"
CARD_HI = "#271F54"
CARD_HOVER = "#33296B"
LINHA = "#3B2F78"
TXT = "#F4F1FF"
SUB = "#A89FD6"
DIM = "#6E679B"
MINT = "#4DF0B5"
MINT_HI = "#86F7CE"
MINT_OFF = "#2B5A5C"
TXT_ESC = "#0B0620"
ROSA = "#FF5FA2"
VIOLETA = "#8B6BFF"
CORAL = "#FF9A62"

# ----------------------------------------------------------------------------
# Escala, fontes e utilidades
# ----------------------------------------------------------------------------
S = 1.0   # fator de escala: 1.0 = 96 dpi
F = None  # fontes (preenchido por iniciar_ui)
ANIM = None  # Animador (preenchido por iniciar_animador)


def px(n):
    return int(round(n * S))


def iniciar_ui(root):
    global S, F
    try:
        S = max(1.0, root.winfo_fpixels("1i") / 96.0)
    except Exception:
        S = 1.0
    try:
        fams = set(tkfont.families(root))
        padrao = tkfont.nametofont("TkDefaultFont").actual("family")
    except Exception:
        fams, padrao = set(), "TkDefaultFont"
    corpo = "Segoe UI" if "Segoe UI" in fams else padrao
    if "Bahnschrift" in fams:
        display = "Bahnschrift"
    elif "Segoe UI Semibold" in fams:
        display = "Segoe UI Semibold"
    else:
        display = corpo
    mono = "Consolas" if "Consolas" in fams else "Courier"
    F = SimpleNamespace(
        marca=(display, 20, "bold"), titulo=(display, 13, "bold"), botao=(display, 14, "bold"),
        botao_p=(display, 10, "bold"), numero=(display, 14, "bold"),
        corpo=(corpo, 10), corpo_b=(corpo, 10, "bold"), pequena=(corpo, 9), mono=(mono, 9),
        lista=(mono, 10), grande=(display, 15, "bold"),
    )


def anim_ligada():
    return ANIM is not None and ANIM.ligado


def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgb_hex(r, g, b):
    return "#%02x%02x%02x" % (int(round(r)), int(round(g)), int(round(b)))


def mix(a, b, t):
    """Cor entre a e b (t de 0 a 1)."""
    t = 0.0 if t < 0 else 1.0 if t > 1 else t
    ra, rb = hex_rgb(a), hex_rgb(b)
    return rgb_hex(*(ra[i] + (rb[i] - ra[i]) * t for i in range(3)))


def ease(t):
    t = 0.0 if t < 0 else 1.0 if t > 1 else t
    return 1 - (1 - t) ** 3


def pontos_arredondados(x1, y1, x2, y2, r):
    """Pontos de um retangulo com cantos arredondados (para create_polygon, sem 'smooth')."""
    r = max(0.0, min(r, (x2 - x1) / 2.0, (y2 - y1) / 2.0))
    pts = []
    for cx, cy, a0 in ((x2 - r, y1 + r, -90), (x2 - r, y2 - r, 0), (x1 + r, y2 - r, 90), (x1 + r, y1 + r, 180)):
        for k in range(0, 91, 15):
            a = math.radians(a0 + k)
            pts += [cx + r * math.cos(a), cy + r * math.sin(a)]
    return pts


def altura_916(largura):
    return int(round(largura * 16 / 9 / 2)) * 2


def fmt_tempo(seg):
    seg = max(0, int(seg))
    h, r = divmod(seg, 3600)
    m, s = divmod(r, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def rotulo(master, texto, fonte, cor=TXT, bg=CARD, **kw):
    return tk.Label(master, text=texto, font=fonte, fg=cor, bg=bg, **kw)


def link(master, texto, comando, bg=CARD):
    lb = tk.Label(master, text=texto, bg=bg, fg=SUB, font=F.pequena, cursor="hand2")
    lb.bind("<Button-1>", lambda _e: comando())
    lb.bind("<Enter>", lambda _e: lb.configure(fg=TXT))
    lb.bind("<Leave>", lambda _e: lb.configure(fg=SUB))
    return lb


# ----------------------------------------------------------------------------
# PNG com transparencia (sem Pillow) para os "brilhos" do fundo
# ----------------------------------------------------------------------------
def png_rgba(arr):
    h, w, _ = arr.shape
    bruto = np.zeros((h, 1 + w * 4), np.uint8)
    bruto[:, 1:] = arr.reshape(h, w * 4)

    def bloco(tag, dados):
        return (struct.pack(">I", len(dados)) + tag + dados
                + struct.pack(">I", zlib.crc32(tag + dados) & 0xFFFFFFFF))

    return (b"\x89PNG\r\n\x1a\n"
            + bloco(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + bloco(b"IDAT", zlib.compress(bruto.tobytes(), 6))
            + bloco(b"IEND", b""))


def brilho_rgba(d, rgb, alfa):
    r = d / 2.0
    y, x = np.mgrid[0:d, 0:d].astype(np.float32)
    dist = np.hypot(x - r + 0.5, y - r + 0.5) / r
    a = np.clip(1.0 - dist, 0.0, 1.0) ** 2.0 * alfa
    arr = np.zeros((d, d, 4), np.uint8)
    arr[..., 0], arr[..., 1], arr[..., 2] = rgb
    arr[..., 3] = (a * 255).astype(np.uint8)
    return arr


# ----------------------------------------------------------------------------
# Animador: um unico relogio para tudo
# ----------------------------------------------------------------------------
class Animador:
    def __init__(self, root, ligado=True):
        self.root = root
        self.itens = []
        self.ligado = bool(ligado)
        self.leve = False       # True enquanto o app processa: menos quadros, menos CPU
        self.on_erro = None
        self._t = time.perf_counter()

    def registrar(self, fn):
        if fn not in self.itens:
            self.itens.append(fn)

    def remover(self, fn):
        try:
            self.itens.remove(fn)
        except ValueError:
            pass

    def iniciar(self):
        self.root.after(33, self._passo)

    def _passo(self):
        agora = time.perf_counter()
        dt = min(max(agora - self._t, 0.0), 0.1)
        self._t = agora
        try:
            iconico = self.root.state() == "iconic"
        except tk.TclError:
            return
        if not iconico:
            for fn in list(self.itens):
                try:
                    fn(dt, agora)
                except tk.TclError:
                    self.remover(fn)
                except Exception as e:  # uma animacao com problema se desliga sozinha
                    self.remover(fn)
                    if self.on_erro:
                        self.on_erro(f"{getattr(fn, '__qualname__', fn)}: {type(e).__name__}: {e}")
        espera = 250 if iconico else (70 if self.leve else 33)
        self.root.after(espera, self._passo)


def iniciar_animador(root, ligado=True):
    global ANIM
    ANIM = Animador(root, ligado)
    ANIM.iniciar()
    return ANIM


# ----------------------------------------------------------------------------
# Fundo animado (a janela inteira)
# ----------------------------------------------------------------------------
class Fundo(tk.Canvas):
    # cor, alfa, diametro, ancora (x, y), amplitude (x, y), velocidade (ciclos/s), fase
    ORBES = [  # ancorados nas bordas e no topo: e ali que o fundo aparece entre os paineis
        (VIOLETA, 0.46, 470, (0.30, 0.03), (0.22, 0.03), (0.031, 0.043), 0.0),
        (ROSA, 0.32, 400, (0.88, 0.05), (0.07, 0.04), (0.040, 0.029), 1.7),
        (MINT, 0.24, 440, (0.97, 0.97), (0.05, 0.05), (0.027, 0.045), 3.1),
        ("#5A3DFF", 0.40, 450, (0.03, 0.97), (0.04, 0.05), (0.035, 0.025), 4.4),
        (CORAL, 0.20, 330, (0.60, 0.99), (0.26, 0.02), (0.022, 0.038), 5.6),
    ]

    def __init__(self, master):
        super().__init__(master, bg=BG, highlightthickness=0, bd=0)
        self.t = 0.0
        self.w = self.h = 1
        self.orbes, self.faiscas, self._refs = [], [], []
        self._acum = 0.0
        self._rng = random.Random(5)
        try:
            self._criar_orbes()
            self._criar_faiscas()
        except Exception:
            pass  # sem o fundo animado o app segue normal
        self.bind("<Configure>", self._redim, add="+")
        if ANIM is not None:
            ANIM.registrar(self._tick)

    def _criar_orbes(self):
        for cor, alfa, diam, anc, amp, vel, fase in self.ORBES:
            d = min(px(diam), 900)
            o = dict(d=d, anc=anc, amp=amp, vel=vel, fase=fase, img=False, it=[])
            try:
                png = png_rgba(brilho_rgba(d, hex_rgb(cor), alfa))
                img = tk.PhotoImage(master=self, data=base64.b64encode(png).decode("ascii"))
                self._refs.append(img)
                o["it"] = [self.create_image(-d, -d, image=img, anchor="center")]
                o["img"] = True
            except Exception:  # sem PNG com transparencia: aneis concentricos
                for k in range(7):
                    r = d / 2.0 * (1 - k / 7.0)
                    c = mix(BG, cor, alfa * 0.55 * ((k + 1) / 7.0) ** 2)
                    o["it"].append(self.create_oval(-r, -r, r, r, fill=c, outline=""))
            self.orbes.append(o)

    def _criar_faiscas(self):
        cores = [mix(BG, MINT, 0.55), mix(BG, ROSA, 0.55), mix(BG, VIOLETA, 0.75), mix(BG, TXT, 0.35)]
        for _ in range(18):
            r = self._rng.uniform(1.2, 3.0) * S
            self.faiscas.append(dict(
                x=self._rng.random(), y=self._rng.random(), r=r,
                v=self._rng.uniform(0.012, 0.034), f=self._rng.uniform(0, 6.28),
                a=self._rng.uniform(0.008, 0.022),
                it=self.create_oval(-9, -9, -8, -8, fill=self._rng.choice(cores), outline="")))

    def _redim(self, e):
        self.w, self.h = max(1, e.width), max(1, e.height)

    def _tick(self, dt, agora):
        if not ANIM.ligado or not self.winfo_ismapped():
            return
        self._acum += dt
        if self._acum < (0.12 if ANIM.leve else 0.05):  # movimento lento: 20 quadros/s bastam
            return
        passo, self._acum = self._acum, 0.0
        self.t += passo
        W, H = self.w, self.h
        for o in self.orbes:
            x = (o["anc"][0] + o["amp"][0] * math.sin(2 * math.pi * o["vel"][0] * self.t + o["fase"])) * W
            y = (o["anc"][1] + o["amp"][1] * math.cos(2 * math.pi * o["vel"][1] * self.t + o["fase"] * 1.3)) * H
            if o["img"]:
                self.coords(o["it"][0], x, y)
            else:
                n = len(o["it"])
                for k, it in enumerate(o["it"]):
                    r = o["d"] / 2.0 * (1 - k / float(n))
                    self.coords(it, x - r, y - r, x + r, y + r)
        for f in self.faiscas:
            f["y"] -= f["v"] * passo
            if f["y"] < -0.03:
                f["y"], f["x"] = 1.03, self._rng.random()
            x = (f["x"] + f["a"] * math.sin(self.t * 0.8 + f["f"])) * W
            y = f["y"] * H
            self.coords(f["it"], x - f["r"], y - f["r"], x + f["r"], y + f["r"])


# ----------------------------------------------------------------------------
# Painel: cartao arredondado desenhado no Fundo; o conteudo vai em .interno
# ----------------------------------------------------------------------------
class Painel:
    def __init__(self, fundo, raio=18, pad=18, cor=CARD, borda=LINHA):
        self.fundo, self.raio, self.pad, self.cor = fundo, px(raio), px(pad), cor
        self.poli = fundo.create_polygon(pontos_arredondados(0, 0, 10, 10, self.raio),
                                         fill=cor, outline=borda, width=1)
        self.interno = tk.Frame(fundo, bg=cor)
        self.jan = fundo.create_window(0, 0, anchor="nw", window=self.interno)
        self.rect = None
        self.visivel = True

    def req_alt(self):
        self.interno.update_idletasks()
        return self.interno.winfo_reqheight() + 2 * self.pad

    def posicionar(self, x, y, w, h):
        rect = (int(x), int(y), int(w), int(h))
        if rect == self.rect:
            return
        self.rect = rect
        x, y, w, h = rect
        self.fundo.coords(self.poli, *pontos_arredondados(x + 1, y + 1, x + w - 1, y + h - 1, self.raio))
        self.fundo.coords(self.jan, x + self.pad, y + self.pad)
        self.fundo.itemconfigure(self.jan, width=max(1, w - 2 * self.pad), height=max(1, h - 2 * self.pad))

    def mostrar(self, sim):
        self.visivel = bool(sim)
        estado = "normal" if sim else "hidden"
        self.fundo.itemconfigure(self.poli, state=estado)
        self.fundo.itemconfigure(self.jan, state=estado)

    def borda(self, cor):
        self.fundo.itemconfigure(self.poli, outline=cor)


# ----------------------------------------------------------------------------
# Botoes e controles (com animacao suave)
# ----------------------------------------------------------------------------
class _Animado:
    """Registra o tick no Animador e solta quando o widget e destruido."""

    def _registrar(self):
        if ANIM is not None:
            ANIM.registrar(self._tick)
        self.bind("<Destroy>", self._destruir, add="+")

    def _destruir(self, e):
        if e.widget is self and ANIM is not None:
            ANIM.remover(self._tick)


class Botao(tk.Canvas, _Animado):
    ESTILOS = {
        "primario": dict(fill=MINT, hover=MINT_HI, texto=TXT_ESC, borda="",
                         off_fill=MINT_OFF, off_texto="#7FB1AE"),
        "suave": dict(fill=CARD_HI, hover=CARD_HOVER, texto=TXT, borda="",
                      off_fill=CARD, off_texto=DIM),
        "fantasma": dict(fill="", hover=CARD_HI, texto=SUB, borda=LINHA,
                         off_fill="", off_texto=DIM),
    }

    def __init__(self, master, texto, comando, estilo="suave", largura=120, altura=36, fonte=None, bg=CARD):
        self.lar, self.alt = px(largura), px(altura)
        super().__init__(master, width=self.lar, height=self.alt, bg=bg,
                         highlightthickness=0, bd=0, cursor="hand2")
        self.bgc = bg
        self.texto, self.comando, self.estilo = texto, comando, estilo
        self.fonte = fonte or F.botao_p
        self.ligado = True
        self.h = self.h_alvo = 0.0
        self.pr = self.pr_alvo = 0.0
        self.brilho = -1.0
        self._fase = random.uniform(0, 3.0)
        self.bind("<Enter>", self._entrar)
        self.bind("<Leave>", self._sair)
        self.bind("<ButtonPress-1>", self._apertar)
        self.bind("<ButtonRelease-1>", self._soltar)
        self._registrar()
        self._desenhar()

    def ativar(self, sim):
        self.ligado = bool(sim)
        self.configure(cursor="hand2" if sim else "arrow")
        self.h_alvo = self.pr_alvo = 0.0
        self.h = self.pr = 0.0
        self.brilho = -1.0
        self._desenhar()

    def definir_texto(self, texto):
        self.texto = texto
        self._desenhar()

    def _alvo(self):
        if not anim_ligada():
            self.h, self.pr = self.h_alvo, self.pr_alvo
            self._desenhar()

    def _entrar(self, _e):
        self.h_alvo = 1.0 if self.ligado else 0.0
        self._alvo()

    def _sair(self, _e):
        self.h_alvo = self.pr_alvo = 0.0
        self._alvo()

    def _apertar(self, _e):
        self.pr_alvo = 1.0 if self.ligado else 0.0
        self._alvo()

    def _soltar(self, e):
        self.pr_alvo = 0.0
        self._alvo()
        if self.ligado and 0 <= e.x <= self.lar and 0 <= e.y <= self.alt:
            self.comando()

    def _tick(self, dt, agora):
        mudou = False
        v = min(1.0, dt * 12)
        for nome, alvo in (("h", self.h_alvo), ("pr", self.pr_alvo)):
            a = getattr(self, nome)
            if abs(a - alvo) > 0.01:
                setattr(self, nome, a + (alvo - a) * v)
                mudou = True
            elif a != alvo:
                setattr(self, nome, alvo)
                mudou = True
        if self.estilo == "primario" and self.ligado and anim_ligada() and not ANIM.leve:
            ciclo = (agora + self._fase) % 4.0
            if ciclo < 0.7:
                self.brilho, mudou = ciclo / 0.7, True
            elif self.brilho >= 0:
                self.brilho, mudou = -1.0, True
        if mudou and self.winfo_ismapped():
            self._desenhar()

    def _desenhar(self):
        self.delete("all")
        est = self.ESTILOS[self.estilo]
        w, h = self.lar, self.alt
        if self.ligado:
            cor = mix(est["fill"] or self.bgc, est["hover"], self.h)
            txt = mix(SUB, TXT, self.h) if self.estilo == "fantasma" else est["texto"]
            borda = mix(LINHA, SUB, self.h * 0.6) if est["borda"] else ""
        else:
            cor, txt, borda = est["off_fill"] or self.bgc, est["off_texto"], est["borda"]
        ins = self.pr * px(2)
        self.create_polygon(pontos_arredondados(1 + ins, 1 + ins, w - 1 - ins, h - 1 - ins, (h - 2 * ins) / 2.0),
                            fill=cor, outline=borda, width=1 if borda else 0)
        if self.ligado and self.estilo == "primario" and 0 <= self.brilho <= 1:
            r = h / 2.0
            x0 = -px(30) + (w + px(60)) * self.brilho
            fx = px(22)

            def cl(x):
                return min(max(x, r), w - r)

            self.create_polygon(cl(x0), px(4), cl(x0 + fx), px(4), cl(x0 + fx - px(8)), h - px(4),
                                cl(x0 - px(8)), h - px(4), fill=mix(cor, "#FFFFFF", 0.45), outline="")
        self.create_text(w / 2.0, h / 2.0 + self.pr, text=self.texto, fill=txt, font=self.fonte)


class Segmentado(tk.Canvas, _Animado):
    """Pilulas de escolha unica com destaque que desliza: [15 s] [30 s] [45 s] [60 s]."""

    def __init__(self, master, opcoes, valor, comando, largura_pilula=58, altura=36, espaco=8, bg=CARD):
        self.opcoes = list(opcoes)
        self.pw, self.alt, self.esp = px(largura_pilula), px(altura), px(espaco)
        self.lar = len(self.opcoes) * self.pw + (len(self.opcoes) - 1) * self.esp
        super().__init__(master, width=self.lar, height=self.alt, bg=bg,
                         highlightthickness=0, bd=0, cursor="hand2")
        self.comando = comando
        self.atual = valor
        self.x_hl = float(self._x(self._idx()))
        self.bind("<ButtonRelease-1>", self._soltar)
        self._registrar()
        self._desenhar()

    @property
    def valor(self):
        return self.atual

    def _x(self, i):
        return i * (self.pw + self.esp)

    def _idx(self):
        for i, (_r, v) in enumerate(self.opcoes):
            if v == self.atual:
                return i
        return 0

    def definir(self, valor):
        self.atual = valor
        if not anim_ligada():
            self.x_hl = float(self._x(self._idx()))
        self._desenhar()

    def _soltar(self, e):
        i = int(e.x // (self.pw + self.esp))
        if 0 <= i < len(self.opcoes) and e.x - i * (self.pw + self.esp) <= self.pw:
            novo = self.opcoes[i][1]
            self.definir(novo)
            if self.comando:
                self.comando(novo)

    def _tick(self, dt, agora):
        alvo = float(self._x(self._idx()))
        if abs(self.x_hl - alvo) > 0.5:
            self.x_hl += (alvo - self.x_hl) * min(1.0, dt * 16)
        elif self.x_hl != alvo:
            self.x_hl = alvo
        else:
            return
        if self.winfo_ismapped():
            self._desenhar()

    def _desenhar(self):
        self.delete("all")
        for i in range(len(self.opcoes)):
            x = self._x(i)
            self.create_polygon(pontos_arredondados(x + 1, 1, x + self.pw - 1, self.alt - 1, self.alt / 2.0),
                                fill=CARD_HI, outline="")
        x = self.x_hl
        self.create_polygon(pontos_arredondados(x + 1, 1, x + self.pw - 1, self.alt - 1, self.alt / 2.0),
                            fill=MINT, outline="")
        for i, (rot, val) in enumerate(self.opcoes):
            self.create_text(self._x(i) + self.pw / 2.0, self.alt / 2.0, text=rot,
                             fill=TXT_ESC if val == self.atual else TXT, font=F.botao_p)


class Stepper(tk.Canvas):
    """[ - ]  5  [ + ]"""

    def __init__(self, master, valor, minimo, maximo, comando, largura=150, altura=40, bg=CARD):
        self.lar, self.alt = px(largura), px(altura)
        super().__init__(master, width=self.lar, height=self.alt, bg=bg,
                         highlightthickness=0, bd=0, cursor="hand2")
        self.minimo, self.maximo, self.comando = minimo, maximo, comando
        self.atual = max(minimo, min(maximo, int(valor)))
        self.bind("<ButtonRelease-1>", self._soltar)
        self._desenhar()

    @property
    def valor(self):
        return self.atual

    def definir(self, v):
        self.atual = max(self.minimo, min(self.maximo, int(v)))
        self._desenhar()

    def _soltar(self, e):
        novo = self.atual
        if e.x < self.alt:
            novo = self.atual - 1
        elif e.x > self.lar - self.alt:
            novo = self.atual + 1
        novo = max(self.minimo, min(self.maximo, novo))
        if novo != self.atual:
            self.atual = novo
            self._desenhar()
            if self.comando:
                self.comando(self.atual)

    def _desenhar(self):
        self.delete("all")
        a = self.alt
        self.create_polygon(pontos_arredondados(1, 1, self.lar - 1, a - 1, a / 2.0), fill=CARD_HI, outline="")
        m = px(4)
        for x0, sinal, ok in ((m, "\u2212", self.atual > self.minimo),
                              (self.lar - a + m, "+", self.atual < self.maximo)):
            self.create_oval(x0, m, x0 + a - 2 * m, a - m, fill=CARD_HOVER if ok else CARD_HI, outline="")
            self.create_text(x0 + (a - 2 * m) / 2.0, a / 2.0, text=sinal, font=F.numero,
                             fill=TXT if ok else DIM)
        self.create_text(self.lar / 2.0, a / 2.0, text=str(self.atual), font=F.numero, fill=TXT)


class Interruptor(tk.Canvas, _Animado):
    def __init__(self, master, valor, comando=None, bg=CARD):
        self.lar, self.alt = px(48), px(28)
        super().__init__(master, width=self.lar, height=self.alt, bg=bg,
                         highlightthickness=0, bd=0, cursor="hand2")
        self.atual, self.comando = bool(valor), comando
        self.pos = 1.0 if self.atual else 0.0
        self.bind("<ButtonRelease-1>", self._soltar)
        self._registrar()
        self._desenhar()

    @property
    def valor(self):
        return self.atual

    def _soltar(self, _e):
        self.atual = not self.atual
        if not anim_ligada():
            self.pos = 1.0 if self.atual else 0.0
        self._desenhar()
        if self.comando:
            self.comando(self.atual)

    def _tick(self, dt, agora):
        alvo = 1.0 if self.atual else 0.0
        if abs(self.pos - alvo) > 0.01:
            self.pos += (alvo - self.pos) * min(1.0, dt * 16)
        elif self.pos != alvo:
            self.pos = alvo
        else:
            return
        if self.winfo_ismapped():
            self._desenhar()

    def _desenhar(self):
        self.delete("all")
        a = self.alt
        self.create_polygon(pontos_arredondados(1, 1, self.lar - 1, a - 1, a / 2.0),
                            fill=mix(LINHA, MINT, self.pos), outline="")
        d = a - px(8)
        x0 = px(4) + (self.lar - px(8) - d) * self.pos
        self.create_oval(x0, px(4), x0 + d, px(4) + d, fill=mix(SUB, TXT_ESC, self.pos), outline="")


class Barra(tk.Canvas, _Animado):
    """Barra de progresso arredondada que desliza ate o valor e brilha enquanto trabalha."""

    def __init__(self, master, altura=10, bg=CARD):
        self.alt = px(altura)
        super().__init__(master, width=px(10), height=self.alt, bg=bg, highlightthickness=0, bd=0)
        self.frac = self.exib = 0.0
        self.ativa = False
        self.fase = 0.0
        self.bind("<Configure>", lambda _e: self._desenhar())
        self._registrar()

    def definir(self, f, imediato=False):
        self.frac = min(max(float(f), 0.0), 1.0)
        if imediato or not anim_ligada():
            self.exib = self.frac
            self._desenhar()

    def ativar(self, sim):
        self.ativa = bool(sim)
        self._desenhar()

    def _tick(self, dt, agora):
        mudou = False
        if abs(self.exib - self.frac) > 0.002:
            self.exib += (self.frac - self.exib) * min(1.0, dt * 9)
            mudou = True
        elif self.exib != self.frac:
            self.exib, mudou = self.frac, True
        if self.ativa and anim_ligada() and self.exib > 0:
            self.fase, mudou = (agora * 0.9) % 1.0, True
        if mudou and self.winfo_ismapped():
            self._desenhar()

    def _desenhar(self):
        self.delete("all")
        w, h = max(self.winfo_width(), 2), self.alt
        self.create_polygon(pontos_arredondados(0, 0, w, h, h / 2.0), fill=CARD_HI, outline="")
        if self.exib > 0:
            fw = max(h, w * self.exib)
            self.create_polygon(pontos_arredondados(0, 0, fw, h, h / 2.0), fill=MINT, outline="")
            if self.ativa and anim_ligada():
                r = h / 2.0
                x0 = -px(30) + (fw + px(60)) * self.fase

                def cl(x):
                    return min(max(x, r), fw - r)

                self.create_polygon(cl(x0), px(1), cl(x0 + px(26)), px(1), cl(x0 + px(18)), h - px(1),
                                    cl(x0 - px(8)), h - px(1), fill=MINT_HI, outline="")


# ----------------------------------------------------------------------------
# Passos (1 Videos > 2 Momentos > 3 Publicar), desenhados direto no Fundo
# ----------------------------------------------------------------------------
class Passos:
    def __init__(self, fundo, rotulos, comando):
        self.f, self.rot, self.cmd = fundo, list(rotulos), comando
        self.atual, self.liberado = 0, 0
        self.x_dir, self.y = 0, 0
        self.fonte = tkfont.Font(root=fundo, font=F.botao_p)
        self.larg = [px(14) * 2 + px(22) + px(8) + self.fonte.measure(r) for r in self.rot]
        self.gap = px(8)
        self.alt = px(34)
        self.x_hl = None
        for i in range(len(self.rot)):
            tag = f"passo{i}"
            fundo.tag_bind(tag, "<Button-1>", lambda _e, i=i: self.cmd(i))
            fundo.tag_bind(tag, "<Enter>", lambda _e: fundo.configure(cursor="hand2"))
            fundo.tag_bind(tag, "<Leave>", lambda _e: fundo.configure(cursor=""))
        if ANIM is not None:
            ANIM.registrar(self._tick)

    def _x(self, i):
        total = sum(self.larg) + self.gap * (len(self.rot) - 1)
        return self.x_dir - total + sum(self.larg[:i]) + self.gap * i

    def posicionar(self, x_dir, y):
        self.x_dir, self.y = x_dir, y
        self.x_hl = None
        self._desenhar()

    def definir(self, atual, liberado):
        ant = self.atual
        self.atual, self.liberado = atual, liberado
        if not anim_ligada():
            self.x_hl = None
        elif ant != atual and self.x_hl is None and self.x_dir > 0:
            self.x_hl = float(self._x(ant))  # o destaque desliza do passo anterior ate o novo
        self._desenhar()

    def _tick(self, dt, agora):
        if self.x_hl is None:
            return
        alvo = float(self._x(self.atual))
        if abs(self.x_hl - alvo) > 0.5:
            self.x_hl += (alvo - self.x_hl) * min(1.0, dt * 14)
        else:
            self.x_hl = None
        self._desenhar()

    def _desenhar(self):
        c = self.f
        c.delete("passos")
        if not self.rot or self.x_dir <= 0:
            return
        alt, y = self.alt, self.y
        xs = [self._x(i) for i in range(len(self.rot))]
        for i, x in enumerate(xs):  # fichas
            c.create_polygon(pontos_arredondados(x, y, x + self.larg[i], y + alt, alt / 2.0),
                             fill=CARD, outline=LINHA, tags=("passos", f"passo{i}"))
        hl = xs[self.atual] if self.x_hl is None else self.x_hl
        # largura do destaque acompanha a ficha de destino
        c.create_polygon(pontos_arredondados(hl, y, hl + self.larg[self.atual], y + alt, alt / 2.0),
                         fill=MINT, outline="", tags=("passos", f"passo{self.atual}"))
        for i, x in enumerate(xs):
            ativo = (i == self.atual)
            livre = i <= self.liberado
            feito = livre and i < self.atual
            cx, cy, r = x + px(14) + px(11), y + alt / 2.0, px(11)
            c.create_oval(cx - r, cy - r, cx + r, cy + r, tags=("passos", f"passo{i}"), outline="",
                          fill=TXT_ESC if ativo else (MINT_OFF if feito else CARD_HI))
            c.create_text(cx, cy, text=str(i + 1), font=F.pequena, tags=("passos", f"passo{i}"),
                          fill=MINT if ativo else (TXT if livre else DIM))
            c.create_text(cx + r + px(8), cy, text=self.rot[i], font=F.botao_p, anchor="w",
                          tags=("passos", f"passo{i}"),
                          fill=TXT_ESC if ativo else (TXT if livre else DIM))


# ----------------------------------------------------------------------------
# Linha do tempo: onde esta a acao e quais cortes foram sugeridos
# ----------------------------------------------------------------------------
class LinhaTempo(tk.Canvas, _Animado):
    def __init__(self, master, altura=92, bg=CARD, ao_selecionar=None, ao_adicionar=None):
        self.alt = px(altura)
        super().__init__(master, height=self.alt, bg=bg, highlightthickness=0, bd=0, cursor="hand2")
        self.curva, self.dur, self.cortes, self.sel = [], 1.0, [], -1
        self.reveal = 1.0
        self.ao_selecionar, self.ao_adicionar = ao_selecionar, ao_adicionar
        self.bind("<Configure>", lambda _e: self._desenhar())
        self.bind("<Button-1>", self._clique)
        self.bind("<Double-Button-1>", self._duplo)
        self.bind("<Motion>", self._mover)
        self.bind("<Leave>", lambda _e: self.delete("hover"))
        self._registrar()

    def definir(self, curva, dur, cortes, sel=-1, animar=True):
        """cortes: lista de (ini, fim, ativo)."""
        self.curva, self.dur = list(curva), max(float(dur), 1.0)
        self.cortes, self.sel = list(cortes), sel
        self.reveal = 0.0 if (animar and anim_ligada()) else 1.0
        self._desenhar()

    def atualizar(self, cortes, sel):
        self.cortes, self.sel = list(cortes), sel
        self._desenhar()

    def _tick(self, dt, agora):
        if self.reveal < 1.0:
            self.reveal = min(1.0, self.reveal + dt * 2.0)
            if self.winfo_ismapped():
                self._desenhar()

    def _geo(self):
        w = max(self.winfo_width(), 2)
        pad, topo, base = px(6), px(20), self.alt - px(18)
        return w, pad, topo, base, max(1, w - 2 * pad)

    def _x_t(self, x):
        _w, pad, _t, _b, aw = self._geo()
        return min(max((x - pad) / aw, 0.0), 1.0) * self.dur

    def _em(self, t):
        for k, (ini, fim, _a) in enumerate(self.cortes):
            if ini <= t <= fim:
                return k
        return -1

    def _clique(self, e):
        k = self._em(self._x_t(e.x))
        if k >= 0 and self.ao_selecionar:
            self.ao_selecionar(k)

    def _duplo(self, e):
        t = self._x_t(e.x)
        if self._em(t) < 0 and self.ao_adicionar:
            self.ao_adicionar(t)

    def _mover(self, e):
        self.delete("hover")
        w, pad, topo, base, aw = self._geo()
        if not self.curva or not (pad <= e.x <= pad + aw):
            return
        self.create_line(e.x, topo - px(6), e.x, base + px(2), fill=SUB, tags="hover")
        self.create_text(e.x + (px(6) if e.x < w / 2 else -px(6)), px(8), text=fmt_tempo(self._x_t(e.x)),
                         anchor="w" if e.x < w / 2 else "e", fill=TXT, font=F.pequena, tags="hover")

    def _desenhar(self):
        self.delete("all")
        w, pad, topo, base, aw = self._geo()
        if not self.curva:
            self.create_text(w / 2.0, self.alt / 2.0, text="Sem dados de análise.", fill=DIM, font=F.pequena)
            return
        n = len(self.curva)
        bw = aw / float(n)
        esc = ease(self.reveal)
        for k, (ini, fim, ativo) in enumerate(self.cortes):  # faixas
            x1, x2 = pad + ini / self.dur * aw, pad + fim / self.dur * aw
            self.create_rectangle(x1, topo - px(6), x2, base + px(2),
                                  fill=mix(CARD, MINT, 0.13) if ativo else mix(CARD, LINHA, 0.45), outline="")
        for i, v in enumerate(self.curva):  # barras de intensidade
            t_mid = (i + 0.5) / n * self.dur
            k = self._em(t_mid)
            if k < 0:
                cor = mix("#3B2F78", "#6A58D8", v)
            elif self.cortes[k][2]:
                cor = mix("#2E8F78", MINT, v)
            else:
                cor = "#5B5486"
            hb = max(px(2), v * (base - topo) * esc)
            x = pad + i * bw
            self.create_rectangle(x, base - hb, x + max(1.0, bw - 1), base, fill=cor, outline="")
        for k, (ini, fim, ativo) in enumerate(self.cortes):  # contornos e numeros
            x1, x2 = pad + ini / self.dur * aw, pad + fim / self.dur * aw
            sel = (k == self.sel)
            if sel:
                self.create_rectangle(x1, topo - px(6), x2, base + px(2), outline=MINT_HI, width=2)
            self.create_text(x1 + px(3), px(8), text=f"#{k + 1}", anchor="w",
                             fill=MINT_HI if sel else (SUB if ativo else DIM), font=F.pequena)
        for frac, anc in ((0.0, "w"), (0.5, "center"), (1.0, "e")):  # marcas de tempo
            x = pad + frac * aw
            self.create_text(x, base + px(10), text=fmt_tempo(frac * self.dur), anchor=anc, fill=DIM, font=F.pequena)


# ----------------------------------------------------------------------------
# Previa 9:16
# ----------------------------------------------------------------------------
def _encolher(img, nh, nw):
    h, w, c = img.shape
    bh, bw = max(1, h // nh), max(1, w // nw)
    return img[: bh * nh, : bw * nw].reshape(nh, bh, nw, bw, c).mean(axis=(1, 3))


def _ampliar(img, nh, nw):
    h, w, _ = img.shape
    y = np.linspace(0, h - 1, nh)
    x = np.linspace(0, w - 1, nw)
    y0 = np.floor(y).astype(int)
    y1 = np.minimum(y0 + 1, h - 1)
    fy = (y - y0)[:, None, None]
    x0 = np.floor(x).astype(int)
    x1 = np.minimum(x0 + 1, w - 1)
    fx = (x - x0)[None, :, None]
    a, b = img[y0][:, x0], img[y0][:, x1]
    c, d = img[y1][:, x0], img[y1][:, x1]
    return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy


def _ppm(arr_uint8):
    h, w, _ = arr_uint8.shape
    return b"P6\n%d %d\n255\n" % (w, h) + arr_uint8.tobytes()


def _cantos(quadro, raio, fundo_rgb):
    h, w, _ = quadro.shape
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    dist = np.hypot(xx - np.clip(xx, raio, w - 1 - raio), yy - np.clip(yy, raio, h - 1 - raio))
    quadro[dist > raio] = fundo_rgb
    return quadro


def moldura_ppm(rgb, raio, fundo_rgb):
    """Quadro real (array HxWx3) com cantos arredondados, em bytes PPM."""
    return _ppm(_cantos(np.clip(rgb.astype(np.float32), 0, 255), raio, fundo_rgb).astype(np.uint8))


def arte_previa(w, h, raio, fundo_rgb):
    """Quadro 9:16 de exemplo: cena de jogo no centro; o fundo e o recorte central da mesma
    cena, ampliado, desfocado e escurecido (como o corte de verdade)."""
    tw, th = w, int(round(w * 9 / 16))
    ys, xs = np.mgrid[0:th, 0:tw].astype(np.float32)
    u, v = xs / (tw - 1), ys / (th - 1)
    topo = np.array([255, 150, 96], np.float32)
    meio = np.array([222, 76, 146], np.float32)
    base = np.array([70, 34, 124], np.float32)
    t = v[..., None]
    cena = np.where(t < 0.55, topo + (meio - topo) * (t / 0.55), meio + (base - meio) * ((t - 0.55) / 0.45))
    d = np.hypot((u - 0.72) * tw, (v - 0.50) * tw)
    sol = np.exp(-(d / (0.17 * th)) ** 2)
    cena = cena + sol[..., None] * np.array([255, 230, 170], np.float32) * 0.9
    rng = np.random.default_rng(7)
    x = 0
    while x < tw:
        bw = int(tw * rng.uniform(0.05, 0.11))
        bh = int(th * rng.uniform(0.16, 0.40))
        cena[th - bh:, x: x + bw] = (24, 14, 56)
        x += bw + int(tw * 0.01)
    cena[int(th * 0.90):, :] = (14, 8, 36)
    cx, cy = tw // 2, int(th * 0.46)
    for dx in (0, 1):
        cena[cy + dx, cx - 10: cx - 3] = 255
        cena[cy + dx, cx + 4: cx + 11] = 255
        cena[cy - 10: cy - 3, cx + dx] = 255
        cena[cy + 4: cy + 11, cx + dx] = 255
    cena[int(th * 0.06): int(th * 0.06) + 4, int(tw * 0.05): int(tw * 0.32)] = hex_rgb(MINT)
    cena = np.clip(cena, 0, 255)
    cw = int(round(th * w / h))
    x0 = (tw - cw) // 2
    pequeno = _encolher(cena[:, x0: x0 + cw], 16, 9)
    quadro = _ampliar(pequeno, h, w) * 0.78 - 4
    y0 = (h - th) // 2
    quadro[y0: y0 + th, :] = cena
    return _ppm(_cantos(np.clip(quadro, 0, 255), raio, fundo_rgb).astype(np.uint8))


class Previa(tk.Canvas, _Animado):
    """O quadro 9:16 do resultado: arte de exemplo, ou o quadro real do corte escolhido."""

    def __init__(self, master, largura=188, bg=CARD):
        self.fw = px(largura)
        self.fh = altura_916(self.fw)
        self.rodape = px(58)
        super().__init__(master, width=self.fw, height=self.fh + self.rodape, bg=bg,
                         highlightthickness=0, bd=0)
        self.bgc, self.raio = bg, px(22)
        self.arte = self.img = None
        self.ocupada = False
        try:
            self.arte = tk.PhotoImage(master=self, data=arte_previa(self.fw, self.fh, self.raio, hex_rgb(bg)),
                                      format="PPM")
            self.item_img = self.create_image(0, 0, image=self.arte, anchor="nw")
        except Exception:
            self.item_img = self.create_polygon(pontos_arredondados(0, 0, self.fw, self.fh, self.raio),
                                                fill="#3A2260", outline="")
        self.create_polygon(pontos_arredondados(1, 1, self.fw - 1, self.fh - 1, self.raio),
                            fill="", outline=LINHA, width=2, tags="moldura")
        cx = self.fw / 2.0
        tile_h = self.fw * 9 / 16
        meio = self.fh / 2.0
        self.create_text(cx, meio - tile_h / 2.0 - px(30), text="Fundo desfocado", fill=TXT,
                         font=F.pequena, tags="legenda")
        self.create_text(cx, meio + tile_h / 2.0 + px(30), text="Gameplay inteira\nno centro", fill=TXT,
                         font=F.pequena, justify="center", tags="legenda")
        self.selo_bg = self.create_polygon(pontos_arredondados(px(10), px(10), px(66), px(30), px(10)),
                                           fill=TXT_ESC, outline="", state="hidden")
        self.selo_tx = self.create_text(px(38), px(20), text="", fill=MINT, font=F.pequena, state="hidden")
        self.scan = [self.create_line(px(6), 0, self.fw - px(6), 0, fill=MINT, width=2, state="hidden")
                     for _ in range(3)]
        base = self.fh + px(24)
        self.t1 = self.create_text(cx, base, text="", fill=TXT, font=F.grande)
        self.t2 = self.create_text(cx, base + px(24), text="", fill=SUB, font=F.pequena, justify="center")
        self._registrar()

    def definir_resumo(self, linha1, linha2):
        self.itemconfigure(self.t1, text=linha1)
        self.itemconfigure(self.t2, text=linha2)

    def mostrar_arte(self):
        if self.arte is not None:
            self.itemconfigure(self.item_img, image=self.arte)
        self.itemconfigure("legenda", state="normal")
        self.itemconfigure(self.selo_bg, state="hidden")
        self.itemconfigure(self.selo_tx, state="hidden")

    def mostrar_quadro(self, rgb, rotulo_tempo=""):
        self.img = tk.PhotoImage(master=self, data=moldura_ppm(rgb, self.raio, hex_rgb(self.bgc)), format="PPM")
        self.itemconfigure(self.item_img, image=self.img)
        self.itemconfigure("legenda", state="hidden")
        if rotulo_tempo:
            self.itemconfigure(self.selo_tx, text=rotulo_tempo, state="normal")
            self.itemconfigure(self.selo_bg, state="normal")
        self.tag_raise("moldura")
        self.tag_raise(self.selo_bg)
        self.tag_raise(self.selo_tx)

    def ocupado(self, sim):
        self.ocupada = bool(sim)
        if not sim:
            for it in self.scan:
                self.itemconfigure(it, state="hidden")

    def _tick(self, dt, agora):
        if not self.ocupada or not anim_ligada() or not self.winfo_ismapped():
            return
        y = ((agora * 0.55) % 1.0) * self.fh
        for k, it in enumerate(self.scan):
            yy = y - k * px(5)
            self.coords(it, px(6), yy, self.fw - px(6), yy)
            self.itemconfigure(it, state="normal" if 0 <= yy <= self.fh else "hidden",
                               fill=mix(MINT, self.bgc, k * 0.35))
            self.tag_raise(it)
