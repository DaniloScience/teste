; Instalador opcional - abra este arquivo no Inno Setup (gratuito) e clique em Compile.
; Rode o build.bat antes, para existir a pasta dist\CortesLauncher.
[Setup]
AppName=Cortes Launcher
AppVersion=0.5.0
SetupIconFile=assets\app.ico
UninstallDisplayIcon={app}\CortesLauncher.exe
DefaultDirName={autopf}\CortesLauncher
DefaultGroupName=Cortes Launcher
OutputBaseFilename=CortesLauncher-Setup
OutputDir=instalador
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64compatible

[Files]
Source: "dist\CortesLauncher\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{group}\Cortes Launcher"; Filename: "{app}\CortesLauncher.exe"
Name: "{autodesktop}\Cortes Launcher"; Filename: "{app}\CortesLauncher.exe"

[Run]
Filename: "{app}\CortesLauncher.exe"; Description: "Abrir o Cortes Launcher"; Flags: nowait postinstall skipifsilent
