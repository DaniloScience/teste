@echo off
setlocal
cd /d "%~dp0"
echo ==== Gerando o app Cortes Launcher ====
if not exist .venv\Scripts\python.exe (
  echo Criando ambiente. So na primeira vez...
  py -3.12 -m venv .venv 2>nul
  if not exist .venv\Scripts\python.exe py -m venv .venv
)
if not exist .venv\Scripts\python.exe (
  echo ERRO: nao consegui criar o ambiente. Instale o Python em python.org.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m pip install --quiet --upgrade pip
.venv\Scripts\python.exe -m pip install --quiet numpy pyinstaller
if errorlevel 1 (
  echo ERRO ao instalar dependencias. Copie a mensagem acima e me mande.
  pause
  exit /b 1
)
echo Empacotando. Isso pode levar varios minutos...
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --windowed --name CortesLauncher --icon assets\app.ico --add-data "assets;assets" --hidden-import edicao launcher.py
if errorlevel 1 (
  echo ERRO ao gerar o app. Copie a mensagem acima e me mande.
  pause
  exit /b 1
)
echo.
echo PRONTO: dist\CortesLauncher\CortesLauncher.exe
echo Para distribuir, envie a pasta dist\CortesLauncher inteira ou gere o instalador com instalador.iss.
pause
