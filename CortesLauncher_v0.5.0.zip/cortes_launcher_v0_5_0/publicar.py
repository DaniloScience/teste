# -*- coding: utf-8 -*-
"""
publicar.py - Sugestoes de titulo, descricao e hashtags para postar os cortes.

Funciona 100% offline (sem IA e sem internet): monta as sugestoes a partir de modelos
de texto, do nome do jogo e da intensidade do corte. Sao PONTOS DE PARTIDA: edite
antes de postar. Nada aqui garante alcance ou resultado.

Limites usados (conferidos em jun/2026; as plataformas mudam, confira antes de postar):
  YouTube Shorts: titulo ate 100 caracteres (no feed aparecem so ~40: as primeiras
                  palavras importam), descricao ate 5.000; as 3 primeiras hashtags
                  da descricao aparecem acima do titulo.
  TikTok:         legenda ate 2.200 caracteres, e as hashtags contam nesse limite.
  Instagram Reels: legenda ate 2.200 caracteres.
Por seguranca o app sugere poucas hashtags (3 a 5) em todas as plataformas.
"""
import random
import re
import unicodedata
from pathlib import Path

TONS = [("Auto", "auto"), ("Ação", "acao"), ("Engraçado", "humor"), ("Suspense", "suspense")]
PLATAFORMAS = [("TikTok", "tiktok"), ("Shorts", "shorts"), ("Reels", "reels")]

LIM_TITULO_SHORTS = 100
LIM_LEGENDA = 2200

# {EM} = "em GTA" ou "nessa gameplay" | {J} = "GTA" ou "essa gameplay" | {N} = numero do corte
TITULOS = {
    "acao": [
        "Isso foi INSANO {EM}",
        "Ninguém esperava esse final {EM}",
        "O momento mais intenso {EM} hoje",
        "O caos tomou conta {EM}",
        "Como eu sobrevivi a isso {EM}?",
        "Eu não acredito no que aconteceu {EM}",
        "Quando tudo dá certo no último segundo {EM}",
        "Jogada de cinema {EM}",
    ],
    "humor": [
        "Eu só queria andar de boa {EM}",
        "Isso não era pra ter acontecido {EM}",
        "Quando o plano dá errado {EM}",
        "Plot twist {EM}",
        "Não era isso que eu tinha planejado {EM}",
        "Confia no processo {EM} (não confia)",
        "Eu e minhas decisões {EM}",
        "Isso devia ser proibido {EM}",
    ],
    "suspense": [
        "Espera até o final {EM}",
        "Parecia tranquilo {EM}... até que",
        "Ninguém viu isso vindo {EM}",
        "Segura o fôlego {EM}",
        "Isso podia ter dado muito errado {EM}",
        "Assiste até o fim {EM}",
        "Olha o que acontece no final {EM}",
        "Eu não devia ter feito isso {EM}",
    ],
    "neutro": [
        "Um momento marcante {EM}",
        "Olha só o que rolou {EM}",
        "Mais um clipe de {J}",
        "Melhores momentos {EM} #{N}",
        "Parte {N}: {J}",
        "Esse trecho de {J} ficou bom",
        "Direto do jogo: {J}",
        "Mais um dia {EM}",
    ],
}

FRASES = {
    "acao": ["Esse trecho foi direto ao ponto.", "A ação não deu trégua nem um segundo.",
             "Não teve nem tempo de respirar."],
    "humor": ["Ri sozinho com essa.", "Nada saiu como o planejado.", "Isso aqui merece replay."],
    "suspense": ["Quase deu ruim. Assista até o fim.", "O final deste corte é o melhor pedaço.",
                 "Segura até o último segundo."],
    "neutro": ["Um trecho que valeu o clipe.", "Mais um corte da gameplay.", "Separei esse momento pra vocês."],
}

CHAMADAS = [
    "Comenta o que você teria feito.",
    "Segue pra ver mais cortes.",
    "Qual jogo você quer ver no próximo vídeo?",
    "Manda pra aquele amigo que joga também.",
    "Já te aconteceu algo parecido? Conta aí.",
]

TAGS_COMUNS = ["#gameplay", "#gamer", "#jogos", "#games", "#clips"]
TAGS_TOM = {
    "acao": ["#insano", "#clutch"],
    "humor": ["#engraçado", "#memes"],
    "suspense": ["#suspense", "#quasenao"],
    "neutro": ["#melhoresmomentos"],
}
QTD_TAGS = {"tiktok": 5, "shorts": 3, "reels": 5}


def _slug(txt):
    s = unicodedata.normalize("NFKD", txt or "").encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-z0-9]", "", s.lower())


def _limitar(txt, n):
    txt = txt.strip()
    return txt if len(txt) <= n else txt[: n - 1].rstrip() + "…"


def _tom_efetivo(tom, nota):
    if tom in ("acao", "humor", "suspense"):
        return tom
    return "acao" if nota >= 0.6 else "neutro"


def _tags(jogo, tom, plataforma):
    base = []
    s = _slug(jogo)
    if s:
        base += [f"#{s}", f"#{s}gameplay"]
    extras = TAGS_TOM.get(tom, []) + TAGS_COMUNS
    if plataforma == "shorts":
        base = ["#Shorts"] + base  # as 3 primeiras aparecem acima do titulo
    vistos, saida = set(), []
    for t in base + extras:
        if t.lower() not in vistos:
            vistos.add(t.lower())
            saida.append(t)
    return saida[: QTD_TAGS.get(plataforma, 5)]


def sugerir(jogo, tom, corte, variante=0):
    """Sugestoes para um corte.
    corte: dict com video, idx, ini, fim, nota. 'variante' muda a sugestao (botao 'Outra').
    Retorna dict com 'tom', 'titulo' e, por plataforma, 'tiktok'/'reels' (legenda pronta)
    e 'shorts' (dict titulo + descricao)."""
    jogo = (jogo or "").strip()
    nota = float(corte.get("nota", 0.5))
    tom_e = _tom_efetivo(tom, nota)
    rng = random.Random(f"{jogo}|{corte.get('video')}|{int(corte.get('ini', 0))}|{variante}|{tom}")
    ctx = {"EM": f"em {jogo}" if jogo else "nessa gameplay",
           "J": jogo or "essa gameplay",
           "N": int(corte.get("idx", 1))}
    titulo = rng.choice(TITULOS[tom_e]).format(**ctx)
    frase = rng.choice(FRASES[tom_e])
    chamada = rng.choice(CHAMADAS)
    tags = {p: _tags(jogo, tom_e, p) for _, p in PLATAFORMAS}

    tiktok = f"{titulo} {' '.join(tags['tiktok'])}"
    reels = f"{titulo}\n\n{frase} {chamada}\n\n{' '.join(tags['reels'])}"
    shorts_desc = f"{frase} {chamada}\n\n{' '.join(tags['shorts'])}"
    return {
        "tom": tom_e,
        "titulo": titulo,
        "tiktok": _limitar(tiktok, LIM_LEGENDA),
        "reels": _limitar(reels, LIM_LEGENDA),
        "shorts": {"titulo": _limitar(titulo, LIM_TITULO_SHORTS), "descricao": shorts_desc},
    }


def texto_plataforma(sug, plataforma):
    """Texto completo de uma plataforma (para copiar/salvar)."""
    if plataforma == "shorts":
        return f"Título: {sug['shorts']['titulo']}\n\nDescrição:\n{sug['shorts']['descricao']}"
    return sug[plataforma]


def salvar_publicacao(pasta, itens):
    """Grava publicacao_cortes.txt ao lado dos cortes.
    itens: lista de (nome_do_arquivo, minutagem, sugestao)."""
    pasta = Path(pasta)
    pasta.mkdir(parents=True, exist_ok=True)
    destino = pasta / "publicacao_cortes.txt"
    linhas = ["TEXTOS PARA POSTAR OS CORTES", "(sugestões automáticas: edite antes de postar)", ""]
    for nome, minutagem, sug in itens:
        linhas += ["=" * 60, f"{nome}   [{minutagem}]", "=" * 60, ""]
        for rotulo, p in PLATAFORMAS:
            linhas += [f"--- {rotulo} ---", texto_plataforma(sug, p), ""]
    destino.write_text("\n".join(linhas), encoding="utf-8-sig")
    return destino
