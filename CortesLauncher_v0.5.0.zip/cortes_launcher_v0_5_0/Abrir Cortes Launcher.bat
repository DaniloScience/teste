@echo off
setlocal
cd /d "%~dp0"
title Cortes Launcher
if exist ".venv\Scripts\pythonw.exe" goto pronto

echo ==== Cortes Launcher ====
echo Preparando o app pela primeira vez. Leva menos de 1 minuto...
py -3.12 -m venv .venv 2>nul
if not exist ".venv\Scripts\python.exe" py -m venv .venv
if not exist ".venv\Scripts\python.exe" goto sem_python
".venv\Scripts\python.exe" -m pip install --quiet --upgrade pip
".venv\Scripts\python.exe" -m pip install --quiet numpy
if errorlevel 1 goto erro_pip

:pronto
if not exist "Cortes Launcher.lnk" powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path (Get-Location) 'Cortes Launcher.lnk')); $s.TargetPath=(Join-Path (Get-Location) '.venv\Scripts\pythonw.exe'); $s.Arguments='launcher.py'; $s.WorkingDirectory=(Get-Location).Path; $s.IconLocation=(Join-Path (Get-Location) 'assets\app.ico'); $s.Description='Cortes Launcher'; $s.Save()" >nul 2>&1
start "" ".venv\Scripts\pythonw.exe" launcher.py
exit /b 0

:sem_python
echo ERRO: nao consegui criar o ambiente.
echo Instale o Python em python.org e marque Add python.exe to PATH.
pause
exit /b 1

:erro_pip
echo ERRO ao instalar. Copie a mensagem acima e me mande.
pause
exit /b 1
