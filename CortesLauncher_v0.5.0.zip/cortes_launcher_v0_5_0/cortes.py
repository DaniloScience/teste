#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cortes.py (v5) - Motor de cortes verticais (9:16) de gameplay.
Usado pelo launcher (launcher.py) e tambem direto pela linha de comando.

O que mudou na v5 (pensando em PC fraco):
  - ANALISAR e RENDERIZAR sao etapas separadas. A analise e leve; o render e o que pesa.
    O launcher mostra as minutagens sugeridas e voce escolhe quais renderizar.
  - A analise fica em cache: mudar quantidade/duracao dos cortes nao reanalisa o video.
  - A analise nao carrega o audio inteiro na memoria (lives de horas funcionam).
  - Tres niveis de render: rapido (720x1280), normal e alta (1080x1920).
  - Cancelar para o FFmpeg na hora; render com porcentagem e tempo estimado.

Estilo "edit" (v0.5): veja edicao.py. Na linha de comando: --estilo edit|montagem,
--visual neon|sangue|cinema, --musica arquivo.mp3, --frases "a / b", --tela-cheia.

Linha de comando:
  python cortes.py gameplay.mp4
  python cortes.py C:\\gameplays -n 8 --len 45 --qualidade rapido
  python cortes.py gameplay.mp4 --dry-run        (so lista as minutagens)
"""
import argparse
import csv
import hashlib
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

import numpy as np

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

VIDEO_EXT = {".mp4", ".mkv", ".mov", ".avi", ".webm", ".ts"}
WIN = 0.5  # segundos por janela de analise
ANALISE_VERSAO = 2  # sobe quando a analise muda (invalida o cache)
FLAGS = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0

QUALIDADES = {
    "rapido": dict(larg=720, preset="veryfast", crf=24, cq=26, nv="p3"),
    "normal": dict(larg=1080, preset="fast", crf=20, cq=21, nv="p5"),
    "alta": dict(larg=1080, preset="medium", crf=18, cq=19, nv="p6"),
}


# ----------------------------------------------------------------------------
# Infra: erros, log, subprocessos
# ----------------------------------------------------------------------------
class ErroCortes(Exception):
    """Erro 'esperado' com mensagem amigavel para o usuario."""


class Cancelado(Exception):
    """O usuario cancelou o processamento."""


_LOG = print


def definir_log(fn):
    global _LOG
    _LOG = fn


def log(*partes):
    try:
        _LOG(" ".join(str(p) for p in partes))
    except Exception:
        pass


def _run(cmd, **kw):
    """subprocess.run sem janela de console e sem depender de stdin (app em modo janela)."""
    kw.setdefault("stdin", subprocess.DEVNULL)
    if FLAGS:
        kw.setdefault("creationflags", FLAGS)
    return subprocess.run(cmd, **kw)


def _popen(cmd, **kw):
    kw.setdefault("stdin", subprocess.DEVNULL)
    if FLAGS:
        kw.setdefault("creationflags", FLAGS)
    return subprocess.Popen(cmd, **kw)


def _matar(proc):
    try:
        if proc.poll() is None:
            proc.kill()
        proc.wait(timeout=5)
    except Exception:
        pass


def _ler_progresso(pipe, estado):
    """Thread: le as linhas 'out_time_us=' que o FFmpeg manda em -progress."""
    try:
        for linha in iter(pipe.readline, b""):
            if linha.startswith((b"out_time_us=", b"out_time_ms=")):
                try:
                    estado["t"] = int(linha.split(b"=", 1)[1]) / 1e6
                except ValueError:
                    pass
    except Exception:
        pass


def _ffmpeg_cancelavel(cmd, checar=None, saida=None, dur=None, progresso=None, cwd=None):
    """Roda o FFmpeg; para na hora se o usuario cancelar. progresso(fracao) opcional."""
    estado = {"t": 0.0}
    with tempfile.TemporaryFile() as err:
        proc = _popen(cmd + ["-progress", "pipe:1", "-nostats"],
                      stdout=subprocess.PIPE, stderr=err, cwd=cwd)
        leitor = threading.Thread(target=_ler_progresso, args=(proc.stdout, estado), daemon=True)
        leitor.start()
        try:
            while True:
                try:
                    rc = proc.wait(timeout=0.25)
                    break
                except subprocess.TimeoutExpired:
                    if checar:
                        checar()
                    if progresso and dur:
                        progresso(min(0.99, estado["t"] / dur))
        except BaseException:
            _matar(proc)
            if saida:
                try:
                    Path(saida).unlink()
                except Exception:
                    pass
            raise
        if rc != 0:
            err.seek(0)
            txt = err.read().decode("utf-8", errors="replace")
            cauda = "\n".join(txt.strip().splitlines()[-6:])
            raise ErroCortes(f"O FFmpeg falhou:\n{cauda}")
    if progresso:
        progresso(1.0)


# ----------------------------------------------------------------------------
# Utilidades
# ----------------------------------------------------------------------------
def ffmpeg_disponivel():
    return bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


def checar_ffmpeg():
    if not ffmpeg_disponivel():
        raise ErroCortes(
            "FFmpeg nao encontrado. No launcher ele e baixado automaticamente; "
            "na linha de comando instale com: winget install Gyan.FFmpeg"
        )


def _probe(path, entries, stream=None):
    cmd = ["ffprobe", "-v", "error"]
    if stream:
        cmd += ["-select_streams", stream]
    cmd += ["-show_entries", entries, "-of", "csv=p=0", str(path)]
    return _run(cmd, capture_output=True, text=True).stdout.strip()


def duracao(path):
    try:
        return float(_probe(path, "format=duration"))
    except ValueError:
        raise ErroCortes(f"Nao consegui ler o video (corrompido ou formato nao suportado): {Path(path).name}")


def dimensoes(path):
    nums = re.findall(r"\d+", _probe(path, "stream=width,height", "v:0"))
    if len(nums) < 2:
        raise ErroCortes(f"O arquivo nao tem faixa de video: {Path(path).name}")
    return int(nums[0]), int(nums[1])


def fmt_t(seg):
    """mm:ss (ou h:mm:ss a partir de 1 hora)."""
    seg = max(0, int(seg))
    h, resto = divmod(seg, 3600)
    m, s = divmod(resto, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def rot_arq(seg):
    """Versao do tempo para nome de arquivo: 05m30s ou 1h05m30s."""
    seg = max(0, int(seg))
    h, resto = divmod(seg, 3600)
    m, s = divmod(resto, 60)
    return f"{h}h{m:02d}m{s:02d}s" if h else f"{m:02d}m{s:02d}s"


def fmt_dur(seg):
    """Tempo restante em texto curto: '45 s', '3 min', '1 h 05 min'."""
    seg = int(max(0, round(seg)))
    if seg < 60:
        return f"{seg} s"
    if seg < 3600:
        return f"{seg // 60} min {seg % 60:02d} s" if seg < 600 else f"{round(seg / 60)} min"
    return f"{seg // 3600} h {(seg % 3600) // 60:02d} min"


def lista_videos(entrada):
    itens = entrada if isinstance(entrada, (list, tuple)) else [entrada]
    videos = []
    for it in itens:
        p = Path(it)
        if p.is_dir():
            videos += sorted(x for x in p.iterdir() if x.suffix.lower() in VIDEO_EXT)
        elif p.is_file():
            videos.append(p)
        else:
            raise ErroCortes(f"Nao achei: {p}")
    vistos, unicos = set(), []
    for v in videos:
        k = str(v.resolve())
        if k not in vistos:
            vistos.add(k)
            unicos.append(v)
    return unicos


def tamanho_saida(larg):
    """(largura, altura) do quadro vertical 9:16 para a largura dada."""
    return int(larg), int(round(larg * 16 / 9 / 2)) * 2


# ----------------------------------------------------------------------------
# Analise (leve): audio + movimento -> nota de 'acao' a cada meio segundo
# ----------------------------------------------------------------------------
def energia_audio(path, dur=None, progresso=None, checar=None):
    """RMS do audio por janela, lendo em blocos (nao carrega o audio inteiro na memoria)."""
    sr = 16000
    cmd = ["ffmpeg", "-v", "error", "-i", str(path), "-vn", "-ac", "1",
           "-ar", str(sr), "-f", "s16le", "-"]
    proc = _popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    passo = int(sr * WIN)
    por_bloco = 240  # janelas por leitura (2 min de audio)
    partes, total = [], 0
    try:
        while True:
            buf = proc.stdout.read(passo * 2 * por_bloco)
            n = len(buf) // (passo * 2)
            if n == 0:
                break
            a = np.frombuffer(buf[: n * passo * 2], dtype=np.int16).astype(np.float32) / 32768.0
            partes.append(np.sqrt((a.reshape(n, passo) ** 2).mean(axis=1)))
            total += n
            if progresso and dur:
                progresso(min(1.0, total * WIN / dur))
            if checar:
                checar()
    finally:
        _matar(proc)
    if total < 2:
        return None
    return np.concatenate(partes)


def energia_movimento(path, dur=None, progresso=None, checar=None):
    """Quanto a imagem muda (64x36 em cinza, 4 quadros/s), media por janela."""
    w, h, fps = 64, 36, 4
    tam = w * h
    cmd = ["ffmpeg", "-v", "error", "-i", str(path), "-an",
           "-vf", f"fps={fps},scale={w}:{h}:flags=fast_bilinear,format=gray",
           "-f", "rawvideo", "-"]
    proc = _popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    prev, partes, lidos = None, [], 0
    try:
        while True:
            buf = proc.stdout.read(tam * 240)
            n = len(buf) // tam
            if n == 0:
                break
            f = np.frombuffer(buf[: n * tam], dtype=np.uint8).reshape(n, tam).astype(np.float32)
            if prev is None:
                d = np.zeros(n, np.float32)
                if n > 1:
                    d[1:] = np.abs(np.diff(f, axis=0)).mean(axis=1)
            else:
                d = np.abs(np.diff(np.vstack([prev, f]), axis=0)).mean(axis=1)
            prev = f[-1:]
            partes.append(d)
            lidos += n
            if progresso and dur:
                progresso(min(1.0, lidos / (fps * dur)))
            if checar:
                checar()
    finally:
        _matar(proc)
    if not partes:
        return None
    d = np.concatenate(partes)
    por = int(fps * WIN)
    n = len(d) // por
    if n == 0:
        return None
    return d[: n * por].reshape(n, por).mean(axis=1)


def normalizar(x):
    lo, hi = np.percentile(x, 5), np.percentile(x, 99)
    if hi - lo < 1e-9:
        return np.zeros_like(x)
    return np.clip((x - lo) / (hi - lo), 0, 1)


def suavizar(x, k=5):
    return np.convolve(x, np.ones(k) / k, mode="same")


def pontuacao(path, dur=None, progresso=None, checar=None, peso_audio=0.6, peso_mov=0.4):
    """Nota de 'acao' a cada meio segundo (audio + movimento), ja suavizada."""
    def p_audio(f):
        if progresso:
            progresso(0.15 * f)

    def p_mov(f):
        if progresso:
            progresso(0.15 + 0.85 * f)

    aud = energia_audio(path, dur, p_audio, checar)
    mov = energia_movimento(path, dur, p_mov, checar)
    partes = []
    if aud is not None:
        partes.append((peso_audio, normalizar(aud)))
    if mov is not None:
        partes.append((peso_mov, normalizar(mov)))
    if not partes:
        raise ErroCortes("Nao consegui analisar audio nem video desse arquivo.")
    n = min(len(p[1]) for p in partes)
    total = sum(p[0] for p in partes)
    bruto = sum(p[0] * p[1][:n] for p in partes) / total
    return suavizar(bruto, 5).astype(np.float32)


def _chave_cache(video):
    p = Path(video).resolve()
    st = p.stat()
    base = f"{ANALISE_VERSAO}|{p}|{st.st_size}|{st.st_mtime_ns}|{WIN}"
    return hashlib.sha1(base.encode("utf-8")).hexdigest()[:20]


def analisar(video, progresso=None, checar=None, cache_dir=None):
    """Analisa um video (ou le do cache). Retorna dict(video, dur, score, cache)."""
    video = Path(video)
    dur = duracao(video)
    arq = None
    if cache_dir:
        try:
            Path(cache_dir).mkdir(parents=True, exist_ok=True)
            arq = Path(cache_dir) / f"{_chave_cache(video)}.npz"
            if arq.exists():
                with np.load(arq) as z:
                    return dict(video=video, dur=float(z["dur"]), score=z["score"].astype(np.float32), cache=True)
        except Exception:
            pass
    score = pontuacao(video, dur, progresso, checar)
    if arq is not None:
        try:
            np.savez_compressed(arq, score=score, dur=dur)
        except Exception:
            pass
    return dict(video=video, dur=dur, score=score, cache=False)


def escolher_cortes(score, dur, n, tam, folga):
    """Escolhe os n melhores trechos de 'tam' segundos, sem sobreposicao."""
    if dur <= tam:
        return [{"ini": 0.0, "fim": dur, "nota": float(score.mean())}]
    janela = int(tam / WIN)
    ultimo = max(0, min(len(score) - janela, int((dur - tam) / WIN)))
    cands = []
    for i in range(0, ultimo + 1):
        trecho = score[i: i + janela]
        if len(trecho) == 0:
            continue
        cands.append((0.5 * trecho.mean() + 0.5 * trecho.max(), i))
    cands.sort(reverse=True)
    escolhidos = []
    for s, i in cands:
        ini = i * WIN
        if all(abs(ini - c["ini"]) >= tam + folga for c in escolhidos):
            escolhidos.append({"ini": ini, "fim": ini + tam, "nota": float(s)})
        if len(escolhidos) >= n:
            break
    return sorted(escolhidos, key=lambda c: c["ini"])


def sugerir(analise, n, tam, folga=5.0):
    """Minutagens sugeridas para uma analise: lista de dicts ini/fim/nota/ativo."""
    cortes = escolher_cortes(analise["score"], analise["dur"], n, tam, folga)
    for c in cortes:
        c["ativo"] = True
    return cortes


def nota_trecho(score, ini, fim):
    a = int(ini / WIN)
    b = max(a + 1, int(fim / WIN))
    t = score[a:b]
    return float(0.5 * t.mean() + 0.5 * t.max()) if len(t) else 0.0


def curva_resumo(score, pontos=240):
    """Curva de intensidade reduzida (maximo por faixa), de 0 a 1, para desenhar a linha do tempo."""
    s = np.asarray(score, dtype=np.float32)
    if len(s) == 0:
        return []
    if len(s) <= pontos:
        out = [float(x) for x in s]
    else:
        e = np.linspace(0, len(s), pontos + 1).astype(int)
        out = [float(s[e[i]: max(e[i + 1], e[i] + 1)].max()) for i in range(pontos)]
    m = max(out) or 1.0
    return [x / m for x in out]


# ----------------------------------------------------------------------------
# Enquadramento: gameplay no centro, fundo desfocado
# ----------------------------------------------------------------------------
def montar_video(dims, larg=1080):
    """Grafo de filtros: [v] = quadro 9:16 com a gameplay inteira no centro e fundo desfocado."""
    W, H = dims
    ow, oh = tamanho_saida(larg)
    if W * 16 >= H * 9:  # mais largo que 9:16 (o normal em gameplay): enche a largura
        fw, fh = ow, max(2, int(round(ow * H / W / 2)) * 2)
    else:                # video ja vertical: enche a altura
        fw, fh = max(2, int(round(oh * W / H / 2)) * 2), oh
    return (
        "[0:v]split=2[bg][fg];"
        "[bg]scale=216:384:force_original_aspect_ratio=increase,crop=216:384,"
        f"boxblur=8:2,scale={ow}:{oh},eq=brightness=-0.10[b];"
        f"[fg]scale={fw}:{fh}[f];"
        "[b][f]overlay=(W-w)/2:(H-h)/2,setsar=1[v]"
    )


def miniatura(src, t, larg=200, dims=None):
    """Quadro do instante t com o MESMO enquadramento do corte. Retorna array (alt, larg, 3) uint8."""
    src = Path(src).resolve()
    dims = dims or dimensoes(src)
    ow, oh = tamanho_saida(larg)
    cmd = ["ffmpeg", "-v", "error", "-ss", f"{max(0.0, t):.2f}", "-i", str(src), "-frames:v", "1",
           "-filter_complex", montar_video(dims, larg), "-map", "[v]",
           "-pix_fmt", "rgb24", "-f", "rawvideo", "-"]
    raw = _run(cmd, capture_output=True).stdout
    if len(raw) != ow * oh * 3:
        raise ErroCortes("Nao consegui extrair o quadro de previa.")
    return np.frombuffer(raw, dtype=np.uint8).reshape(oh, ow, 3).copy()


# ----------------------------------------------------------------------------
# Renderizacao (a parte pesada)
# ----------------------------------------------------------------------------
def _qualidade(args):
    return QUALIDADES.get(getattr(args, "qualidade", "normal"), QUALIDADES["normal"])


def _cmd_render(src, ini, dur, saida, grafo, q, nvenc):
    cmd = ["ffmpeg", "-y", "-v", "error", "-ss", f"{ini:.2f}", "-t", f"{dur:.2f}",
           "-i", str(src), "-filter_complex", grafo,
           "-map", "[v]", "-map", "0:a:0?"]
    if nvenc:
        cmd += ["-c:v", "h264_nvenc", "-preset", q["nv"], "-cq", str(q["cq"])]
    else:
        cmd += ["-c:v", "libx264", "-preset", q["preset"], "-crf", str(q["crf"])]
    cmd += ["-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
            "-t", f"{dur:.2f}", "-movflags", "+faststart", str(saida)]
    return cmd


def renderizar(src, corte, saida, args, checar=None, progresso=None):
    if getattr(args, "estilo", "limpo") in ("edit", "montagem"):
        import edicao
        return edicao.renderizar_edit(src, corte, saida, args, checar, progresso)
    src, saida = Path(src).resolve(), Path(saida).resolve()
    ini, dur = corte["ini"], corte["fim"] - corte["ini"]
    q = _qualidade(args)
    grafo = montar_video(dimensoes(src), q["larg"])
    nvenc = bool(getattr(args, "nvenc", False))
    try:
        _ffmpeg_cancelavel(_cmd_render(src, ini, dur, saida, grafo, q, nvenc),
                           checar, saida, dur, progresso)
    except ErroCortes:
        if not nvenc:
            raise
        log("      a placa NVIDIA nao respondeu; usando o processador neste corte.")
        _ffmpeg_cancelavel(_cmd_render(src, ini, dur, saida, grafo, q, False),
                           checar, saida, dur, progresso)


def renderizar_lista(trabalhos, pasta_saida, args, progresso=None, checar=None):
    """Renderiza so os trabalhos pedidos. trabalhos: dicts com video, idx, ini, fim, nota.
    progresso(fracao, texto). Retorna a lista de dicts prontos (com 'arquivo')."""
    pasta_saida = Path(pasta_saida)
    pasta_saida.mkdir(parents=True, exist_ok=True)
    total = len(trabalhos)
    prontos, t0 = [], time.time()
    for k, tr in enumerate(trabalhos):
        if checar:
            checar()
        v = Path(tr["video"])
        nome = f"{v.stem}_corte{tr['idx']:02d}_{rot_arq(tr['ini'])}.mp4"
        eta = ""
        if k > 0:
            media = (time.time() - t0) / k
            eta = f" - faltam ~{fmt_dur(media * (total - k))}"
        texto = f"Renderizando corte {k + 1} de {total}{eta}"
        log(f"   #{tr['idx']:02d}  {fmt_t(tr['ini'])} -> {fmt_t(tr['fim'])}   {v.name}")

        def prog(f, k=k, texto=texto):
            if progresso:
                progresso((k + f) / total, f"{texto}  ({int(f * 100)}%)")

        prog(0.0)
        renderizar(v, tr, pasta_saida / nome, args, checar, prog)
        log(f"      pronto: {nome}")
        prontos.append(dict(tr, arquivo=pasta_saida / nome))
    _escrever_relatorio(pasta_saida, prontos)
    if progresso:
        progresso(1.0, "Pronto!")
    return prontos


def _escrever_relatorio(pasta_saida, prontos):
    if not prontos:
        return
    csv_path = Path(pasta_saida) / "relatorio_cortes.csv"
    novo = not csv_path.exists()
    try:
        with open(csv_path, "a", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f, delimiter=";")
            if novo:
                w.writerow(["video", "corte", "inicio", "fim", "nota", "arquivo"])
            for p in prontos:
                w.writerow([Path(p["video"]).name, p["idx"], fmt_t(p["ini"]), fmt_t(p["fim"]),
                            f"{p['nota']:.2f}", Path(p["arquivo"]).name])
    except OSError as e:
        log(f"Nao consegui gravar o relatorio: {e}")


# ----------------------------------------------------------------------------
# Tudo de uma vez (linha de comando e 'Cortar direto')
# ----------------------------------------------------------------------------
def rodar(args, progresso=None, cancelar=None, cache_dir=None):
    """Analisa e renderiza tudo. 'progresso(fracao, texto)' e 'cancelar.is_set()' sao opcionais."""
    def prog(f, t):
        if progresso:
            progresso(min(max(f, 0.0), 1.0), t)

    def checar():
        if cancelar is not None and cancelar.is_set():
            raise Cancelado()

    checar_ffmpeg()
    videos = lista_videos(args.entrada)
    if not videos:
        raise ErroCortes("Nenhum video encontrado.")
    pasta_saida = Path(args.saida)
    pasta_saida.mkdir(parents=True, exist_ok=True)

    parte_analise = 0.3 if not args.dry_run else 1.0
    trabalhos, linhas_dry = [], []
    for vi, v in enumerate(videos):
        checar()
        log(f"\n=== {v.name} ===")
        an = analisar(v, lambda f, vi=vi, v=v: prog((vi + f) / len(videos) * parte_analise,
                                                    f"Analisando {v.name}..."),
                      checar, cache_dir)
        cortes = sugerir(an, args.n, args.len, args.gap)
        log(f"  duracao {fmt_t(an['dur'])}  |  {len(cortes)} cortes sugeridos:")
        for i, c in enumerate(cortes, 1):
            log(f"   #{i}  {fmt_t(c['ini'])} -> {fmt_t(c['fim'])}   nota {c['nota']:.2f}")
            trabalhos.append(dict(video=v, idx=i, ini=c["ini"], fim=c["fim"], nota=c["nota"], score=an["score"]))
            linhas_dry.append(dict(trabalhos[-1], arquivo=Path("(nao renderizado)")))

    if args.dry_run:
        _escrever_relatorio(pasta_saida, linhas_dry)
        prog(1.0, "Pronto!")
        return {"saida": pasta_saida, "linhas": linhas_dry, "arquivos": [], "prontos": []}

    prontos = renderizar_lista(
        trabalhos, pasta_saida, args,
        lambda f, t: prog(parte_analise + f * (1 - parte_analise), t), checar)
    log(f"\nPronto. Cortes em: {pasta_saida.resolve()}")
    return {"saida": pasta_saida, "linhas": prontos,
            "arquivos": [p["arquivo"] for p in prontos], "prontos": prontos}


# ----------------------------------------------------------------------------
# Linha de comando
# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="Cortes verticais automaticos de gameplay")
    ap.add_argument("entrada", help="arquivo de video ou pasta com videos")
    ap.add_argument("-o", "--saida", default="saida", help="pasta de saida (padrao: saida)")
    ap.add_argument("-n", type=int, default=5, help="cortes por video (padrao: 5)")
    ap.add_argument("--len", type=float, default=30, help="duracao de cada corte em s (padrao: 30)")
    ap.add_argument("--gap", type=float, default=5, help="folga minima entre cortes em s")
    ap.add_argument("--qualidade", choices=list(QUALIDADES), default="normal",
                    help="rapido (720p, PC fraco), normal ou alta (padrao: normal)")
    ap.add_argument("--nvenc", action="store_true", help="usar GPU NVIDIA para renderizar")
    ap.add_argument("--dry-run", action="store_true", help="so lista as minutagens, sem renderizar")
    ap.add_argument("--estilo", choices=["limpo", "edit", "montagem"], default="limpo",
                    help="limpo (so o corte), edit (efeitos na batida) ou montagem (cortes rapidos)")
    ap.add_argument("--visual", choices=["neon", "sangue", "cinema"], default="neon",
                    help="visual do edit (cor, brilho, texto)")
    ap.add_argument("--musica", default="", help="arquivo de musica (so use musica livre de direitos)")
    ap.add_argument("--frases", default="", help='frases na tela separadas por /  (ex.: "vice city / 2026")')
    ap.add_argument("--tela-cheia", action="store_true", help="preenche a tela 9:16 (corta as laterais)")
    args = ap.parse_args()
    args.frases = [t.strip() for t in args.frases.split("/") if t.strip()]
    args.tela_cheia = bool(args.tela_cheia)

    try:
        rodar(args)
    except ErroCortes as e:
        sys.exit(f"ERRO: {e}")


if __name__ == "__main__":
    main()
