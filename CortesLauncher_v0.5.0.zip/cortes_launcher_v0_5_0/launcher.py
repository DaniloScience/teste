# -*- coding: utf-8 -*-
"""
Cortes Launcher (v0.5) - interface do motor de cortes (cortes.py).

Fluxo em 3 etapas:
  1. Videos    - escolha arquivos, pasta ou cole o link de uma live. Clique em "Analisar momentos".
  2. Momentos  - o app SUGERE as minutagens (analise leve). Marque so os que quer, ajuste, e
                 renderize apenas esses (a renderizacao e a parte pesada em PC fraco).
  3. Publicar  - titulo, descricao e hashtags sugeridos para TikTok, Shorts e Reels.

Saida: 9:16 com a gameplay inteira no centro e fundo desfocado, so o corte limpo (sem legenda,
zoom, titulo ou musica) para voce finalizar no seu editor.
Na primeira vez o app baixa sozinho o FFmpeg (e o yt-dlp, se usar link).
"""
import json
import os
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import traceback
import urllib.request
import zipfile
from pathlib import Path
from types import SimpleNamespace

# App em modo janela (PyInstaller --windowed): stdout/stderr podem ser None
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w", encoding="utf-8")

import tkinter as tk
from tkinter import filedialog, messagebox

import baixador
import cortes
import publicar
import visual as V
from visual import px, rotulo, link, Botao, Segmentado, Stepper, Interruptor, Barra
from visual import Painel, Fundo, Passos, LinhaTempo, Previa

APP_NAME = "Cortes Launcher"  # nome provisorio: troque aqui e no build.bat
APP_SLUG = "CortesLauncher"
VERSAO = "0.5.0"


def recurso(nome):
    """Arquivo da pasta assets, tanto rodando pelo Python quanto dentro do .exe (PyInstaller)."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / "assets" / nome

FFMPEG_URLS = [
    "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
    "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip",
]

DURACOES = [15, 30, 45, 60]
QUALIDADES_UI = [("Rápido", "rapido"), ("Normal", "normal"), ("Alta", "alta")]
ESTILOS_UI = [("Limpo", "limpo"), ("Edit", "edit"), ("Montagem", "montagem")]
VISUAIS_UI = [("Neon", "neon"), ("Sangue", "sangue"), ("Cinema", "cinema")]
ENQUADRAMENTO_UI = [("Com fundo", False), ("Tela cheia", True)]
ESTILO_TXT = {"limpo": "", "edit": " · Edit", "montagem": " · Montagem"}
AUDIO_EXT = [("Música", "*.mp3 *.wav *.m4a *.aac *.ogg *.flac"), ("Todos os arquivos", "*.*")]
RES_TXT = {"rapido": "720 × 1280", "normal": "1080 × 1920", "alta": "1080 × 1920 (alta)"}

CONFIG_PADRAO = dict(n=5, dur=30, nvenc=False, saida="", aviso_dl=False,
                     qualidade="normal", anim=True, jogo="", tom="auto",
                     estilo="limpo", visual="neon", tela_cheia=False, musica="", frases="")

AVISO_DL = (
    "Baixe apenas vídeos que sejam seus ou que você tenha permissão para usar.\n\n"
    "Baixar e republicar o conteúdo de outras pessoas pode violar os termos da "
    "plataforma e os direitos autorais.\n\nContinuar?"
)
DICA_LINK = "Cole o link da live ou do vídeo"


# ----------------------------------------------------------------------------
# Pastas, configuracao e FFmpeg
# ----------------------------------------------------------------------------
def dados_dir():
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / ".local" / "share")
    p = Path(base) / APP_SLUG
    p.mkdir(parents=True, exist_ok=True)
    return p


def docs_dir():
    p = Path.home() / "Documents" / APP_NAME
    p.mkdir(parents=True, exist_ok=True)
    return p


def carregar_config():
    cfg = dict(CONFIG_PADRAO)
    try:
        cfg.update(json.loads((dados_dir() / "config.json").read_text(encoding="utf-8")))
    except Exception:
        pass
    return cfg


def salvar_config(cfg):
    try:
        (dados_dir() / "config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def ffmpeg_dir():
    return dados_dir() / "ffmpeg"


def ytdlp_dir():
    return dados_dir() / "ytdlp"


def cache_analises_dir():
    return dados_dir() / "analises"


def downloads_dir():
    p = docs_dir() / "downloads"
    p.mkdir(parents=True, exist_ok=True)
    return p


def preparar_path():
    d = str(ffmpeg_dir())
    partes = os.environ.get("PATH", "").split(os.pathsep)
    if d not in partes:
        os.environ["PATH"] = d + os.pathsep + os.environ.get("PATH", "")


def extrair_ffmpeg_zip(zip_path, destino):
    """Tira ffmpeg e ffprobe de dentro do zip (qualquer subpasta '/bin/')."""
    destino = Path(destino)
    destino.mkdir(parents=True, exist_ok=True)
    achou = set()
    with zipfile.ZipFile(zip_path) as z:
        for nome in z.namelist():
            norm = nome.replace("\\", "/")
            base = norm.split("/")[-1].lower()
            if "/bin/" in norm and base in ("ffmpeg.exe", "ffprobe.exe", "ffmpeg", "ffprobe"):
                with z.open(nome) as src, open(destino / base, "wb") as dst:
                    shutil.copyfileobj(src, dst)
                achou.add(base.replace(".exe", ""))
    if not {"ffmpeg", "ffprobe"} <= achou:
        raise RuntimeError("O arquivo baixado não contém o FFmpeg esperado.")


def baixar_ffmpeg(progresso):
    """Baixa o FFmpeg para a pasta do app. progresso(fracao_ou_None, bytes_baixados)."""
    ultimo_erro = None
    for url in FFMPEG_URLS:
        try:
            with tempfile.TemporaryDirectory() as tmp:
                zp = Path(tmp) / "ffmpeg.zip"
                req = urllib.request.Request(url, headers={"User-Agent": f"{APP_SLUG}/{VERSAO}"})
                with urllib.request.urlopen(req, timeout=30) as r, open(zp, "wb") as out:
                    total = int(r.headers.get("Content-Length") or 0)
                    feito = 0
                    while True:
                        bloco = r.read(256 * 1024)
                        if not bloco:
                            break
                        out.write(bloco)
                        feito += len(bloco)
                        progresso(feito / total if total else None, feito)
                extrair_ffmpeg_zip(zp, ffmpeg_dir())
            preparar_path()
            return
        except Exception as e:  # tenta o proximo link
            ultimo_erro = e
    raise RuntimeError(
        f"Não consegui baixar o FFmpeg ({ultimo_erro}). "
        "Verifique sua internet (ou antivírus/firewall) e tente de novo."
    )


def cortes_estilos():
    return ("limpo", "edit", "montagem")


def plural(n, um, varios):
    return f"{n} {um if n == 1 else varios}"


def curto(caminho, limite=34):
    s = str(caminho)
    if len(s) <= limite:
        return s
    return s[:12] + "\u2026" + s[-(limite - 13):]


# ----------------------------------------------------------------------------
# Aplicativo
# ----------------------------------------------------------------------------
class App:
    PASSOS = ["Vídeos", "Momentos", "Publicar"]

    def __init__(self, root):
        self.root = root
        root.title(APP_NAME)
        root.configure(bg=V.BG)
        self._icone()
        V.iniciar_ui(root)

        self.cfg = carregar_config()
        V.iniciar_animador(root, self.cfg.get("anim", True))
        V.ANIM.on_erro = lambda m: self._log("[animação] " + m)

        self.fila = queue.Queue()
        self.cancelar_ev = threading.Event()
        self.rodando = False
        self.fase = None  # "link", "analise" ou "render" enquanto roda
        self._ph_ativo = False
        self.videos = []
        self.analises = {}    # Path -> dict(dur, score, curva)
        self.itens = []       # momentos sugeridos (de todos os videos), em ordem
        self.sel = -1         # indice em self.itens
        self.prontos = []     # cortes renderizados
        self.pub_sel = -1
        self.pub_var = {}     # arquivo -> numero da variante de texto
        self.pub_sug = None
        self.passo = 0
        self.liberado = 0
        self.log_visivel = False
        self.avancado = False
        self._layout_job = None
        self._linha_video = None
        self._thumb_job = None
        self._thumb_chave = None
        self._thumb_cache = {}
        self._pub_job = None
        self.pasta_saida = Path(self.cfg["saida"]) if self.cfg["saida"] else docs_dir() / "saida"
        self.var_status = tk.StringVar(master=root, value="Adicione um vídeo para começar.")
        self.var_saida_txt = tk.StringVar(master=root, value=curto(self.pasta_saida))

        self._ui()
        self._atualizar_lista()
        self._tamanho_inicial()
        self._barra_escura()
        self._ir_passo(0, forcar=True)
        root.protocol("WM_DELETE_WINDOW", self._fechar)
        root.after(100, self._poll)

    def _icone(self):
        """Icone da janela e da barra de tarefas (nao quebra o app se faltar o arquivo)."""
        try:
            ico = recurso("app.ico")
            if os.name == "nt" and ico.exists():
                self.root.iconbitmap(default=str(ico))
        except Exception:
            pass
        try:
            png = recurso("logo_256.png")
            if png.exists():
                self._icone_img = tk.PhotoImage(master=self.root, file=str(png))
                self.root.iconphoto(True, self._icone_img)
        except Exception:
            pass

    def _carregar_logo(self):
        """Logo do cabecalho, no tamanho mais proximo da escala da tela (40, 60 ou 80 px)."""
        try:
            alvo = px(40)
            tam = min((40, 60, 80), key=lambda t: abs(t - alvo))
            arq = recurso(f"logo_{tam}.png")
            return tk.PhotoImage(master=self.root, file=str(arq)) if arq.exists() else None
        except Exception:
            return None

    # ======================================================================
    # Interface
    # ======================================================================
    def _ui(self):
        r = self.root
        f = self.fundo = Fundo(r)
        f.pack(fill="both", expand=True)
        m = px(26)

        # cabecalho: logo + nome (itens soltos no fundo animado)
        self._logo_img = self._carregar_logo()
        if self._logo_img is not None:
            f.create_image(m, px(22), image=self._logo_img, anchor="nw")
        else:  # sem o arquivo da logo: desenho simples
            f.create_polygon(V.pontos_arredondados(m + px(2), px(22), m + px(32), px(64), px(7)),
                             fill="#2E8F78", outline="")
            f.create_rectangle(m + px(2), px(36), m + px(32), px(36) + int(px(30) * 9 / 16) + px(1),
                               fill=V.MINT, outline="")
        f.create_text(m + px(48), px(33), text=APP_NAME, font=V.F.marca, fill=V.TXT, anchor="w")
        f.create_text(m + px(48), px(57), text="Os melhores momentos da sua gameplay, em vertical.",
                      font=V.F.corpo, fill=V.SUB, anchor="w")
        self._ver = f.create_text(0, 0, text=f"v{VERSAO}", font=V.F.pequena, fill=V.DIM, anchor="e")
        self.passos = Passos(f, self.PASSOS, self._clicar_passo)

        # paineis
        self.p_videos = Painel(f)
        self._conteudo_videos(self.p_videos.interno)
        self.p_ajustes = Painel(f)
        self._conteudo_ajustes(self.p_ajustes.interno)
        self.p_momentos = Painel(f)
        self._conteudo_momentos(self.p_momentos.interno)
        self.p_publicar = Painel(f)
        self._conteudo_publicar(self.p_publicar.interno)
        self.p_previa = Painel(f, pad=16)
        self.previa = Previa(self.p_previa.interno, 176)
        self.previa.pack()
        self.p_dock = Painel(f, raio=22, pad=16)
        self._conteudo_dock(self.p_dock.interno)
        self.p_log = Painel(f, pad=10)
        self._conteudo_log(self.p_log.interno)
        for p in (self.p_momentos, self.p_publicar, self.p_log):
            p.mostrar(False)

        # rodape: itens soltos
        self._rod_aviso = f.create_text(m, 0, anchor="w", font=V.F.pequena, fill=V.SUB,
                                        text="Respeite a política de conteúdo do jogo e os direitos de quem aparece nos vídeos.")
        self._rod_det = f.create_text(0, 0, anchor="e", font=V.F.pequena, fill=V.SUB, text="Mostrar detalhes",
                                      tags="lnk_det")
        self._rod_log = f.create_text(0, 0, anchor="e", font=V.F.pequena, fill=V.SUB, text="Copiar log",
                                      tags="lnk_log")
        for tag, item, cmd in (("lnk_det", self._rod_det, self._alternar_log),
                               ("lnk_log", self._rod_log, self._copiar_log)):
            f.tag_bind(tag, "<Button-1>", lambda _e, c=cmd: c())
            f.tag_bind(tag, "<Enter>", lambda _e, it=item: (f.itemconfigure(it, fill=V.TXT), f.configure(cursor="hand2")))
            f.tag_bind(tag, "<Leave>", lambda _e, it=item: (f.itemconfigure(it, fill=V.SUB), f.configure(cursor="")))
        f.bind("<Configure>", lambda _e: self._agendar_layout(), add="+")

    # ---------------- cartao: videos ----------------
    def _conteudo_videos(self, i):
        cab = tk.Frame(i, bg=V.CARD)
        cab.pack(fill="x")
        rotulo(cab, "Seus vídeos", V.F.titulo).pack(side="left")
        self.lbl_qtd = rotulo(cab, "", V.F.corpo, V.SUB)
        self.lbl_qtd.pack(side="right")

        lk = tk.Frame(i, bg=V.CARD)  # baixar por link (live / video)
        lk.pack(fill="x", pady=(px(10), 0))
        self.var_link = tk.StringVar(master=self.root, value="")
        self.ent_link = tk.Entry(lk, textvariable=self.var_link, font=V.F.corpo, bg=V.CARD_HI, fg=V.TXT,
                                 insertbackground=V.TXT, relief="flat", bd=0, highlightthickness=1,
                                 highlightbackground=V.LINHA, highlightcolor=V.MINT)
        self.ent_link.pack(side="left", fill="x", expand=True, ipady=px(8))
        self.btn_baixar = Botao(lk, "Só baixar", lambda: self.baixar_link(False), "suave", 96, 36)
        self.btn_baixar.pack(side="left", padx=(px(10), 0))
        self.btn_baixar_cortar = Botao(lk, "Baixar e analisar", lambda: self.baixar_link(True), "primario", 160, 36)
        self.btn_baixar_cortar.pack(side="left", padx=(px(8), 0))
        self.ent_link.bind("<FocusIn>", self._esconder_dica)
        self.ent_link.bind("<FocusOut>", self._mostrar_dica)
        self.ent_link.bind("<Return>", lambda _e: self.baixar_link(True))
        menu = tk.Menu(self.ent_link, tearoff=0)
        menu.add_command(label="Colar", command=lambda: self.ent_link.event_generate("<<Paste>>"))
        self.ent_link.bind("<Button-3>", lambda e: (self.ent_link.focus_set(), menu.tk_popup(e.x_root, e.y_root)))
        self._mostrar_dica()

        corpo = tk.Frame(i, bg=V.CARD, height=px(106))
        corpo.pack(fill="x", pady=(px(10), 0))
        corpo.pack_propagate(False)

        self.f_vazio = tk.Frame(corpo, bg=V.CARD)  # estado vazio
        centro = tk.Frame(self.f_vazio, bg=V.CARD)
        centro.pack(expand=True)
        rotulo(centro, "Escolha a gameplay que você quer cortar", V.F.titulo).pack()
        rotulo(centro, "Funciona com qualquer jogo. Aceita MP4, MKV, MOV, AVI, WEBM e TS.",
               V.F.pequena, V.SUB).pack(pady=(px(2), px(12)))
        bt = tk.Frame(centro, bg=V.CARD)
        bt.pack()
        Botao(bt, "Escolher vídeos", self.add_videos, "primario", 170, 38).pack(side="left")
        Botao(bt, "Escolher pasta", self.add_pasta, "fantasma", 150, 38).pack(side="left", padx=(px(10), 0))

        self.f_lista = tk.Frame(corpo, bg=V.CARD)  # estado com videos
        self.lista = tk.Listbox(self.f_lista, height=3, bg=V.CARD_HI, fg=V.TXT, selectbackground=V.MINT,
                                selectforeground=V.TXT_ESC, relief="flat", bd=0, highlightthickness=0,
                                activestyle="none", font=V.F.corpo)
        self.lista.pack(fill="x")
        self.lista.bind("<Delete>", lambda _e: self._remover_selecionado())
        bt2 = tk.Frame(self.f_lista, bg=V.CARD)
        bt2.pack(fill="x", pady=(px(10), 0))
        Botao(bt2, "Adicionar vídeos", self.add_videos, "suave", 150, 34).pack(side="left")
        Botao(bt2, "Adicionar pasta", self.add_pasta, "suave", 140, 34).pack(side="left", padx=(px(8), 0))
        Botao(bt2, "Limpar", self.limpar, "fantasma", 90, 34).pack(side="right")

    # ---------------- cartao: ajustes ----------------
    def _conteudo_ajustes(self, i):
        i.grid_columnconfigure(0, weight=1)

        def linha(pai, r, titulo, sub, widget):
            txt = tk.Frame(pai, bg=V.CARD)
            txt.grid(row=r, column=0, sticky="w", pady=(0 if r == 0 else px(10), 0))
            rotulo(txt, titulo, V.F.corpo_b).pack(anchor="w")
            if isinstance(sub, tk.StringVar):
                tk.Label(txt, textvariable=sub, font=V.F.pequena, fg=V.SUB, bg=V.CARD).pack(anchor="w")
            else:
                rotulo(txt, sub, V.F.pequena, V.SUB).pack(anchor="w")
            widget.grid(row=r, column=1, sticky="e", padx=(px(16), 0), pady=(0 if r == 0 else px(10), 0))

        dur = min(DURACOES, key=lambda d: abs(d - float(self.cfg["dur"])))
        n = max(1, min(30, int(float(self.cfg["n"]))))
        self.stepper = Stepper(i, n, 1, 30, lambda _v: self._atualizar_resumo())
        linha(i, 0, "Sugestões por vídeo", "Quantos momentos com mais ação o app sugere.", self.stepper)
        self.seg = Segmentado(i, [(f"{d} s", d) for d in DURACOES], dur, lambda _v: self._atualizar_resumo())
        linha(i, 1, "Duração de cada corte", "Quanto tempo cada corte dura.", self.seg)
        q = self.cfg.get("qualidade", "normal")
        self.seg_q = Segmentado(i, QUALIDADES_UI, q if q in cortes.QUALIDADES else "normal",
                                lambda _v: self._atualizar_resumo(), largura_pilula=78)
        linha(i, 2, "Velocidade da renderização", "PC fraco? Use Rápido (720p): leva bem menos tempo.", self.seg_q)

        est = self.cfg.get("estilo", "limpo")
        self.seg_estilo = Segmentado(i, ESTILOS_UI, est if est in cortes_estilos() else "limpo",
                                     self._trocou_estilo, largura_pilula=84)
        linha(i, 3, "Estilo do corte", "Edit = efeitos na batida. Montagem = cortes rápidos.",
              self.seg_estilo)

        # opcoes do estilo Edit/Montagem (aparecem so quando o estilo nao e "Limpo")
        self.f_edit = tk.Frame(i, bg=V.CARD)
        self.f_edit.grid(row=4, column=0, columnspan=2, sticky="ew")
        self.f_edit.grid_columnconfigure(0, weight=1)
        vis = self.cfg.get("visual", "neon")
        self.seg_visual = Segmentado(self.f_edit, VISUAIS_UI, vis if vis in ("neon", "sangue", "cinema") else "neon",
                                     lambda _v: None, largura_pilula=78)
        linha(self.f_edit, 0, "Visual", "Cor, brilho e granulação do edit.", self.seg_visual)
        self.musica = self.cfg.get("musica", "") if Path(self.cfg.get("musica", "") or "-").is_file() else ""
        self.var_musica_txt = tk.StringVar(master=self.root, value=self._texto_musica())
        bm = tk.Frame(self.f_edit, bg=V.CARD)
        Botao(bm, "Escolher", self.escolher_musica, "suave", 90, 34).pack(side="left")
        Botao(bm, "Tirar", self.tirar_musica, "fantasma", 70, 34).pack(side="left", padx=(px(8), 0))
        linha(self.f_edit, 1, "Música", self.var_musica_txt, bm)
        self.var_frases = tk.StringVar(master=self.root, value=self.cfg.get("frases", ""))
        ef = tk.Entry(self.f_edit, textvariable=self.var_frases, font=V.F.corpo, bg=V.CARD_HI, fg=V.TXT,
                      insertbackground=V.TXT, relief="flat", bd=0, highlightthickness=1,
                      highlightbackground=V.LINHA, highlightcolor=V.MINT, width=26)
        linha(self.f_edit, 2, "Frases na tela", "Separe com /  (ex.: vice city / 2026)", ef)
        ef.grid_configure(ipady=px(6))
        if self.seg_estilo.valor == "limpo":
            self.f_edit.grid_remove()

        self.lnk_avanc = link(i, "Mais opções ▾", self._alternar_avanc)
        self.lnk_avanc.grid(row=5, column=0, sticky="w", pady=(px(10), 0))
        self.f_avanc = tk.Frame(i, bg=V.CARD)
        self.f_avanc.grid(row=6, column=0, columnspan=2, sticky="ew")
        self.f_avanc.grid_columnconfigure(0, weight=1)
        self.sw = Interruptor(self.f_avanc, self.cfg["nvenc"])
        linha(self.f_avanc, 0, "Placa NVIDIA", "Gera mais rápido em placas GeForce.", self.sw)
        self.sw_anim = Interruptor(self.f_avanc, self.cfg.get("anim", True), self._ligar_animacoes)
        linha(self.f_avanc, 1, "Animações", "Desligue em PC fraco para poupar processador.", self.sw_anim)
        bt = tk.Frame(self.f_avanc, bg=V.CARD)
        Botao(bt, "Trocar", self.trocar_saida, "suave", 80, 34).pack(side="left")
        Botao(bt, "Abrir", lambda: self._abrir(self.pasta_saida), "fantasma", 80, 34).pack(side="left", padx=(px(8), 0))
        linha(self.f_avanc, 2, "Salvar cortes em", self.var_saida_txt, bt)
        self.seg_enq = Segmentado(self.f_avanc, ENQUADRAMENTO_UI, bool(self.cfg.get("tela_cheia", False)),
                                  lambda _v: None, largura_pilula=96)
        linha(self.f_avanc, 3, "Enquadramento (Edit/Montagem)", "Tela cheia corta as laterais da gameplay.",
              self.seg_enq)
        self.f_avanc.grid_remove()

    # ---------------- cartao: momentos (etapa 2) ----------------
    def _conteudo_momentos(self, i):
        cab = tk.Frame(i, bg=V.CARD)
        cab.pack(fill="x")
        rotulo(cab, "Momentos sugeridos", V.F.titulo).pack(side="left")
        self.lbl_resumo_m = rotulo(cab, "", V.F.corpo, V.SUB)
        self.lbl_resumo_m.pack(side="right")
        rotulo(i, "Marque só o que vale a pena: quanto menos cortes, menos tempo de renderização.",
               V.F.pequena, V.SUB).pack(anchor="w", pady=(px(2), px(8)))
        self.lbl_video_m = rotulo(i, "", V.F.corpo_b, V.TXT)
        self.lbl_video_m.pack(anchor="w")
        self.linha = LinhaTempo(i, 92, V.CARD, self._tl_selecionar, self._tl_adicionar)
        self.linha.pack(fill="x", pady=(px(4), px(2)))
        rotulo(i, "Clique num corte para ver a prévia. Duplo clique num ponto vazio adiciona um corte.",
               V.F.pequena, V.DIM).pack(anchor="w")

        meio = tk.Frame(i, bg=V.CARD)
        meio.pack(fill="both", expand=True, pady=(px(8), 0))
        self.lista_m = tk.Listbox(meio, bg=V.CARD_HI, fg=V.TXT, selectbackground=V.MINT,
                                  selectforeground=V.TXT_ESC, relief="flat", bd=0, highlightthickness=0,
                                  activestyle="none", font=V.F.lista, selectmode="browse", exportselection=False)
        sb = tk.Scrollbar(meio, command=self.lista_m.yview, bg=V.CARD_HI, troughcolor=V.CARD,
                          relief="flat", bd=0, highlightthickness=0)
        self.lista_m.configure(yscrollcommand=sb.set)
        self.lista_m.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.lista_m.bind("<<ListboxSelect>>", self._lista_selecionou)
        self.lista_m.bind("<Double-Button-1>", lambda _e: self._alternar_sel())
        self.lista_m.bind("<space>", lambda _e: (self._alternar_sel(), "break")[1])
        self.lista_m.bind("<Delete>", lambda _e: self._remover_momento())

        bt = tk.Frame(i, bg=V.CARD)
        bt.pack(fill="x", pady=(px(8), 0))
        Botao(bt, "Marcar / desmarcar", self._alternar_sel, "suave", 150, 32).pack(side="left")
        Botao(bt, "−1 s", lambda: self._mover(-1), "suave", 64, 32).pack(side="left", padx=(px(8), 0))
        Botao(bt, "+1 s", lambda: self._mover(1), "suave", 64, 32).pack(side="left", padx=(px(6), 0))
        Botao(bt, "Remover", self._remover_momento, "fantasma", 84, 32).pack(side="left", padx=(px(8), 0))
        Botao(bt, "Nenhum", lambda: self._marcar_todos(False), "fantasma", 80, 32).pack(side="right")
        Botao(bt, "Todos", lambda: self._marcar_todos(True), "fantasma", 70, 32).pack(side="right", padx=(0, px(6)))

    # ---------------- cartao: publicacao (etapa 3) ----------------
    def _conteudo_publicar(self, i):
        cab = tk.Frame(i, bg=V.CARD)
        cab.pack(fill="x")
        rotulo(cab, "Publicação", V.F.titulo).pack(side="left")
        self.lbl_resumo_p = rotulo(cab, "", V.F.corpo, V.SUB)
        self.lbl_resumo_p.pack(side="right")
        rotulo(i, "Sugestões automáticas (sem IA, sem internet): use como ponto de partida e edite antes de postar.",
               V.F.pequena, V.SUB).pack(anchor="w", pady=(px(2), px(8)))

        corpo = tk.Frame(i, bg=V.CARD)
        corpo.pack(fill="both", expand=True)
        corpo.grid_columnconfigure(1, weight=1)
        corpo.grid_rowconfigure(0, weight=1)

        esq = tk.Frame(corpo, bg=V.CARD)
        esq.grid(row=0, column=0, sticky="ns", padx=(0, px(16)))
        rotulo(esq, "Cortes prontos", V.F.corpo_b).pack(anchor="w", pady=(0, px(4)))
        self.lista_p = tk.Listbox(esq, width=26, bg=V.CARD_HI, fg=V.TXT, selectbackground=V.MINT,
                                  selectforeground=V.TXT_ESC, relief="flat", bd=0, highlightthickness=0,
                                  activestyle="none", font=V.F.lista, selectmode="browse", exportselection=False)
        self.lista_p.pack(fill="both", expand=True)
        self.lista_p.bind("<<ListboxSelect>>", self._pub_lista_selecionou)

        dir_ = tk.Frame(corpo, bg=V.CARD)
        dir_.grid(row=0, column=1, sticky="nsew")
        dir_.grid_columnconfigure(1, weight=1)
        dir_.grid_rowconfigure(3, weight=1)

        rotulo(dir_, "Jogo", V.F.corpo_b).grid(row=0, column=0, sticky="w")
        self.var_jogo = tk.StringVar(master=self.root, value=self.cfg.get("jogo", ""))
        ent = tk.Entry(dir_, textvariable=self.var_jogo, font=V.F.corpo, bg=V.CARD_HI, fg=V.TXT,
                       insertbackground=V.TXT, relief="flat", bd=0, highlightthickness=1,
                       highlightbackground=V.LINHA, highlightcolor=V.MINT)
        ent.grid(row=0, column=1, sticky="ew", padx=(px(12), 0), ipady=px(6))
        ent.bind("<KeyRelease>", lambda _e: self._pub_agendar())
        rotulo(dir_, "Tom", V.F.corpo_b).grid(row=1, column=0, sticky="w", pady=(px(8), 0))
        tom = self.cfg.get("tom", "auto")
        self.seg_tom = Segmentado(dir_, publicar.TONS, tom if tom in dict((v, 1) for _r, v in publicar.TONS) else "auto",
                                  lambda _v: self._pub_preencher(), largura_pilula=72, altura=32, espaco=6)
        self.seg_tom.grid(row=1, column=1, sticky="w", padx=(px(12), 0), pady=(px(8), 0))
        rotulo(dir_, "Postar em", V.F.corpo_b).grid(row=2, column=0, sticky="w", pady=(px(8), 0))
        self.pub_plat = "tiktok"
        self.seg_plat = Segmentado(dir_, publicar.PLATAFORMAS, "tiktok", self._pub_trocar_plat,
                                   largura_pilula=84, altura=32, espaco=6)
        self.seg_plat.grid(row=2, column=1, sticky="w", padx=(px(12), 0), pady=(px(8), 0))

        txt = tk.Frame(dir_, bg=V.CARD)
        txt.grid(row=3, column=0, columnspan=2, sticky="nsew", pady=(px(10), 0))
        self.f_titulo = tk.Frame(txt, bg=V.CARD)  # so no Shorts (titulo separado da descricao)
        self.var_titulo = tk.StringVar(master=self.root, value="")
        self.ent_titulo = tk.Entry(self.f_titulo, textvariable=self.var_titulo, font=V.F.corpo, bg=V.CARD_HI,
                                   fg=V.TXT, insertbackground=V.TXT, relief="flat", bd=0, highlightthickness=1,
                                   highlightbackground=V.LINHA, highlightcolor=V.MINT)
        self.ent_titulo.pack(side="left", fill="x", expand=True, ipady=px(6))
        self.ent_titulo.bind("<KeyRelease>", lambda _e: self._pub_contador())
        self.lbl_cont_t = rotulo(self.f_titulo, "", V.F.pequena, V.SUB)
        self.lbl_cont_t.pack(side="left", padx=(px(8), 0))
        self.txt_pub = tk.Text(txt, height=6, bg=V.CARD_HI, fg=V.TXT, insertbackground=V.TXT, relief="flat",
                               font=V.F.corpo, wrap="word", padx=px(8), pady=px(6), highlightthickness=1,
                               highlightbackground=V.LINHA, highlightcolor=V.MINT, undo=True)
        self.txt_pub.pack(fill="both", expand=True, pady=(px(8), 0))
        self.txt_pub.bind("<KeyRelease>", lambda _e: self._pub_contador())
        self.lbl_cont = rotulo(txt, "", V.F.pequena, V.SUB)
        self.lbl_cont.pack(anchor="e", pady=(px(2), 0))
        bt = tk.Frame(txt, bg=V.CARD)
        bt.pack(fill="x", pady=(px(4), 0))
        self.btn_copiar_t = Botao(bt, "Copiar título", self._pub_copiar_titulo, "suave", 120, 32)
        self.btn_copiar_t.pack(side="left", padx=(0, px(8)))
        Botao(bt, "Copiar texto", self._pub_copiar_texto, "primario", 120, 32).pack(side="left")
        Botao(bt, "Outra sugestão", self._pub_outra, "fantasma", 130, 32).pack(side="right")

    # ---------------- dock (botao principal + progresso) ----------------
    def _conteudo_dock(self, i):
        i.grid_columnconfigure(1, weight=1)
        i.grid_rowconfigure(0, weight=1)
        self.btn_gerar = Botao(i, "Analisar momentos", self._acao_principal, "primario", 250, 54, V.F.botao)
        self.btn_gerar.grid(row=0, column=0)
        prog = tk.Frame(i, bg=V.CARD)
        prog.grid(row=0, column=1, sticky="ew", padx=px(18))
        tk.Label(prog, textvariable=self.var_status, font=V.F.corpo, fg=V.SUB, bg=V.CARD, anchor="w").pack(fill="x")
        self.barra = Barra(prog, 10, V.CARD)
        self.barra.pack(fill="x", pady=(px(8), 0))
        self.btn_sec = Botao(i, "Cortar direto", self._acao_secundaria, "fantasma", 170, 40)
        self.btn_sec.grid(row=0, column=2)
        self.btn_cancelar = Botao(i, "Cancelar", self.cancelar, "fantasma", 110, 40)
        self.btn_cancelar.grid(row=0, column=2)
        self.btn_cancelar.grid_remove()

    def _conteudo_log(self, i):
        self.txt_log = tk.Text(i, height=7, bg=V.CARD, fg=V.TXT, relief="flat", font=V.F.mono,
                               highlightthickness=0, wrap="word", state="disabled", insertbackground=V.TXT)
        sb = tk.Scrollbar(i, command=self.txt_log.yview, bg=V.CARD_HI, troughcolor=V.CARD,
                          relief="flat", bd=0, highlightthickness=0)
        self.txt_log.configure(yscrollcommand=sb.set)
        self.txt_log.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

    # ======================================================================
    # Layout (posiciona os paineis sobre o fundo animado)
    # ======================================================================
    def _agendar_layout(self):
        if self._layout_job is None:
            self._layout_job = self.root.after(15, self._layout)

    def _medidas(self):
        return px(26), px(14), px(84), px(26), px(80)  # margem, vao, topo, rodape, dock

    def _layout(self):
        self._layout_job = None
        f = self.fundo
        W, H = f.winfo_width(), f.winfo_height()
        if W < px(400) or H < px(300):
            return
        m, gap, topo, rod, dock_h = self._medidas()
        self.passos.posicionar(W - m, px(20))
        f.coords(self._ver, W - m, px(66))
        f.coords(self._rod_aviso, m, H - px(13))
        f.coords(self._rod_det, W - m, H - px(13))
        bb = f.bbox(self._rod_det)
        larg_det = (bb[2] - bb[0]) if bb else px(100)
        f.coords(self._rod_log, W - m - larg_det - px(16), H - px(13))

        y_base = H - rod
        if self.log_visivel:
            log_h = px(150)
            self.p_log.posicionar(m, y_base - log_h, W - 2 * m, log_h)
            self.p_log.mostrar(True)
            y_base -= log_h + gap
        else:
            self.p_log.mostrar(False)
        y_dock = y_base - dock_h
        self.p_dock.posicionar(m, y_dock, W - 2 * m, dock_h)

        corpo_h = max(px(120), y_dock - gap - topo)
        pw = self.previa.fw + 2 * self.p_previa.pad
        self.p_previa.posicionar(W - m - pw, topo, pw, min(self.p_previa.req_alt(), corpo_h))
        lx, lw = m, max(px(300), W - 2 * m - gap - pw)
        if self.passo == 0:
            h1 = min(self.p_videos.req_alt(), corpo_h)
            h2 = max(px(60), min(self.p_ajustes.req_alt(), corpo_h - h1 - gap))
            self.p_videos.posicionar(lx, topo, lw, h1)
            self.p_ajustes.posicionar(lx, topo + h1 + gap, lw, h2)
        elif self.passo == 1:
            self.p_momentos.posicionar(lx, topo, lw, corpo_h)
        else:
            self.p_publicar.posicionar(lx, topo, lw, corpo_h)

    def _altura_minima(self):
        m, gap, topo, rod, dock_h = self._medidas()
        if self.passo == 0:
            corpo = self.p_videos.req_alt() + gap + self.p_ajustes.req_alt()
        else:
            corpo = px(400)
        corpo = max(corpo, self.p_previa.req_alt())
        extra = (px(150) + gap) if self.log_visivel else 0
        return topo + corpo + gap + dock_h + extra + rod

    def _garantir_altura(self):
        r = self.root
        r.update_idletasks()
        alvo = min(self._altura_minima(), r.winfo_screenheight() - px(70))
        if r.winfo_height() < alvo:
            r.geometry(f"{r.winfo_width()}x{alvo}")

    def _tamanho_inicial(self):
        r = self.root
        r.update_idletasks()
        sw, sh = r.winfo_screenwidth(), r.winfo_screenheight()
        w = min(px(1060), sw - px(40))
        h = min(max(self._altura_minima() + px(10), px(690)), sh - px(80))
        r.geometry(f"{w}x{h}+{max(0, (sw - w) // 2)}+{max(0, (sh - h) // 3)}")
        r.minsize(min(w, px(960)), min(h, px(620)))

    def _barra_escura(self):
        """Barra de titulo escura no Windows 10/11 (se nao der, segue com a padrao)."""
        try:
            import ctypes
            self.root.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(self.root.winfo_id())
            val = ctypes.c_int(1)
            for attr in (20, 19):
                if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(val), ctypes.sizeof(val)) == 0:
                    break
        except Exception:
            pass

    # ======================================================================
    # Etapas
    # ======================================================================
    def _clicar_passo(self, i):
        if not self.rodando:
            self._ir_passo(i)

    def _ir_passo(self, n, forcar=False):
        if not forcar and n > self.liberado:
            return
        self.passo = n
        self.p_videos.mostrar(n == 0)
        self.p_ajustes.mostrar(n == 0)
        self.p_momentos.mostrar(n == 1)
        self.p_publicar.mostrar(n == 2)
        self.passos.definir(n, self.liberado)
        if n == 0:
            self.previa.mostrar_arte()
        elif n == 1:
            self._refrescar_momentos(self.sel if self.sel >= 0 else 0)
        else:
            self._entrar_publicar()
        self._atualizar_botoes()
        self._atualizar_resumo()
        self._status_padrao()
        self._agendar_layout()

    def _status_padrao(self):
        if self.rodando:
            return
        if self.passo == 0:
            self.var_status.set("Pronto para analisar." if self.videos else "Adicione um vídeo para começar.")
        elif self.passo == 1:
            self.var_status.set("Marque os momentos que quer renderizar.")
        else:
            self.var_status.set(f"{plural(len(self.prontos), 'corte pronto', 'cortes prontos')}. Copie os textos para postar.")

    def _n_marcados(self):
        return sum(1 for it in self.itens if it["ativo"])

    def _atualizar_botoes(self):
        if self.passo == 0:
            txt, sec, ok = "Analisar momentos", "Cortar direto", True
        elif self.passo == 1:
            n = self._n_marcados()
            txt, sec, ok = f"Renderizar {plural(n, 'corte', 'cortes')}", "Copiar minutagens", n > 0
        else:
            txt, sec, ok = "Abrir pasta dos cortes", "Salvar textos (.txt)", True
        self.btn_gerar.definir_texto(txt)
        self.btn_sec.definir_texto(sec)
        self.btn_gerar.ativar(ok and not self.rodando)

    def _acao_principal(self):
        if self.passo == 0:
            self.analisar()
        elif self.passo == 1:
            self.renderizar()
        else:
            self._abrir(self.pasta_saida)

    def _acao_secundaria(self):
        if self.passo == 0:
            self.analisar(direto=True)
        elif self.passo == 1:
            self._copiar_minutagens()
        else:
            self._salvar_textos()

    def _atualizar_resumo(self):
        res = RES_TXT.get(self.seg_q.valor, "1080 × 1920") + ESTILO_TXT.get(self.seg_estilo.valor, "")
        if self.passo == 0:
            n, d, v = int(self.stepper.valor), int(self.seg.valor), len(self.videos)
            if v == 0:
                l1, l2 = f"{plural(n, 'sugestão', 'sugestões')} de {d} s", f"por vídeo, em {res}"
            else:
                l1 = f"Até {plural(n * v, 'sugestão', 'sugestões')}"
                l2 = f"{plural(v, 'vídeo', 'vídeos')}, {d} s cada, em {res}"
        elif self.passo == 1:
            n = self._n_marcados()
            seg = sum(it["fim"] - it["ini"] for it in self.itens if it["ativo"])
            l1, l2 = plural(n, "corte marcado", "cortes marcados"), f"{cortes.fmt_dur(seg)} de vídeo, em {res}"
        else:
            l1 = plural(len(self.prontos), "corte pronto", "cortes prontos")
            l2 = f"em {curto(self.pasta_saida, 22)}"
        self.previa.definir_resumo(l1, l2)

    # ======================================================================
    # Link (yt-dlp)
    # ======================================================================
    def _texto_link(self):
        return "" if self._ph_ativo else self.var_link.get().strip()

    def _mostrar_dica(self, _e=None):
        if not self.var_link.get().strip():
            self._ph_ativo = True
            self.var_link.set(DICA_LINK)
            self.ent_link.configure(fg=V.SUB)

    def _esconder_dica(self, _e=None):
        if self._ph_ativo:
            self._ph_ativo = False
            self.var_link.set("")
            self.ent_link.configure(fg=V.TXT)

    def _limpar_link(self):
        self._ph_ativo = False
        self.var_link.set("")
        self._mostrar_dica()

    def baixar_link(self, analisar=False):
        if self.rodando:
            return
        try:
            url = baixador.normalizar_url(self._texto_link())
        except cortes.ErroCortes as e:
            messagebox.showinfo(APP_NAME, str(e))
            return
        if not self.cfg.get("aviso_dl"):
            if not messagebox.askyesno(APP_NAME, AVISO_DL):
                return
            self.cfg["aviso_dl"] = True
            salvar_config(self.cfg)
        if not baixador.ytdlp_exe(ytdlp_dir()).exists() or not cortes.ffmpeg_disponivel():
            if not messagebox.askyesno(
                    APP_NAME,
                    "Na primeira vez preciso baixar o yt-dlp (cerca de 20 MB) e, se ainda não tiver, "
                    "o FFmpeg (cerca de 100 MB). Isso é feito uma única vez.\n\nContinuar?"):
                return
        self.fase = "link"
        self._set_rodando(True)
        self.barra.definir(0, True)
        self.cancelar_ev.clear()
        self._log("--- baixando link ---")
        threading.Thread(target=self._worker_link, args=(url, analisar), daemon=True).start()

    def _worker_link(self, url, analisar):
        def st(texto, frac=None):
            self.fila.put(("st", frac, texto))

        def prog(frac, eta, vel):
            partes = [f"{frac * 100:.0f}%"]
            if vel:
                partes.append(vel)
            if eta:
                partes.append(f"falta {eta}")
            self.fila.put(("st", frac, "Baixando o vídeo... " + " · ".join(partes)))

        try:
            if not cortes.ffmpeg_disponivel():
                baixar_ffmpeg(lambda frac, feito: st(f"Baixando o FFmpeg... {feito / 1048576:.0f} MB", frac))
            if self.cancelar_ev.is_set():
                raise cortes.Cancelado()
            arq = baixador.baixar_por_link(
                url, downloads_dir(), ytdlp_dir(), ffmpeg_dir(), f"{APP_SLUG}/{VERSAO}",
                progresso=prog, log=lambda s: self.fila.put(("log", s)), status=st,
                cancelar=self.cancelar_ev)
            self.fila.put(("link_ok", arq, analisar))
        except cortes.Cancelado:
            self.fila.put(("cancelado",))
        except cortes.ErroCortes as e:
            self.fila.put(("erro", str(e)))
        except Exception as e:
            self.fila.put(("log", traceback.format_exc()))
            self.fila.put(("erro", f"Algo deu errado ao baixar: {type(e).__name__}: {e}"))

    def _link_pronto(self, arq, analisar):
        self._set_rodando(False)
        self.barra.definir(0, True)
        self._add(arq)
        self._atualizar_lista()
        self._limpar_link()
        self._log(f"Baixado: {arq}")
        if analisar:
            self.analisar(so=arq)
        else:
            self.var_status.set("Vídeo baixado e adicionado. Clique em Analisar momentos.")

    # ======================================================================
    # Videos / pastas
    # ======================================================================
    def add_videos(self):
        tipos = [("Vídeos", "*.mp4 *.mkv *.mov *.avi *.webm *.ts"), ("Todos os arquivos", "*.*")]
        for fl in filedialog.askopenfilenames(title="Escolha os vídeos", filetypes=tipos):
            self._add(Path(fl))
        self._atualizar_lista()

    def add_pasta(self):
        d = filedialog.askdirectory(title="Escolha a pasta com os vídeos")
        if d:
            for v in sorted(Path(d).iterdir()):
                if v.suffix.lower() in cortes.VIDEO_EXT:
                    self._add(v)
            self._atualizar_lista()

    def _add(self, p):
        if p not in self.videos:
            self.videos.append(p)

    def limpar(self):
        self.videos = []
        self.analises.clear()
        self.itens = []
        self.sel = -1
        self.liberado = 0
        self._atualizar_lista()
        self.passos.definir(self.passo, self.liberado)

    def _remover_selecionado(self):
        for idx in reversed(list(self.lista.curselection())):
            if 0 <= idx < len(self.videos):
                v = self.videos.pop(idx)
                self.analises.pop(v, None)
                self.itens = [it for it in self.itens if it["video"] != v]
        self._atualizar_lista()

    def _atualizar_lista(self):
        self.lista.delete(0, "end")
        for v in self.videos:
            self.lista.insert("end", v.name)
        n = len(self.videos)
        self.lbl_qtd.configure(text="" if n == 0 else plural(n, "vídeo", "vídeos"))
        if n:
            self.f_vazio.pack_forget()
            self.f_lista.pack(fill="both", expand=True)
        else:
            self.f_lista.pack_forget()
            self.f_vazio.pack(fill="both", expand=True)
        if not self.rodando and self.passo == 0:
            self._status_padrao()
        self._atualizar_resumo()

    def _trocou_estilo(self, v):
        if v == "limpo":
            self.f_edit.grid_remove()
        else:
            self.f_edit.grid()
        self.root.update_idletasks()
        self._garantir_altura()
        self._agendar_layout()
        self._atualizar_resumo()

    def _texto_musica(self):
        if self.musica:
            return curto(self.musica, 40)
        return "Sem música: usa os impactos do áudio do jogo."

    def escolher_musica(self):
        f = filedialog.askopenfilename(title="Escolha a música (use só música livre de direitos)",
                                       filetypes=AUDIO_EXT)
        if f:
            self.musica = f
            self.var_musica_txt.set(self._texto_musica())

    def tirar_musica(self):
        self.musica = ""
        self.var_musica_txt.set(self._texto_musica())

    def _frases(self):
        bruto = self.var_frases.get().replace("|", "/").replace("\n", "/")
        return [t.strip() for t in bruto.split("/") if t.strip()][:8]

    def trocar_saida(self):
        d = filedialog.askdirectory(title="Onde salvar os cortes?")
        if d:
            self.pasta_saida = Path(d)
            self.var_saida_txt.set(curto(self.pasta_saida))

    def _alternar_avanc(self):
        self.avancado = not self.avancado
        if self.avancado:
            self.f_avanc.grid()
            self.lnk_avanc.configure(text="Menos opções ▴")
        else:
            self.f_avanc.grid_remove()
            self.lnk_avanc.configure(text="Mais opções ▾")
        self.root.update_idletasks()
        self._garantir_altura()
        self._agendar_layout()

    def _ligar_animacoes(self, sim):
        V.ANIM.ligado = bool(sim)
        self.cfg["anim"] = bool(sim)
        salvar_config(self.cfg)

    # ======================================================================
    # Analise (etapa 1 -> 2)
    # ======================================================================
    def _precisa_ffmpeg(self):
        if cortes.ffmpeg_disponivel():
            return False
        if messagebox.askyesno(
                APP_NAME,
                "Na primeira vez preciso baixar o FFmpeg (cerca de 100 MB). "
                "Isso é feito uma única vez.\n\nBaixar agora?"):
            self._baixar_ffmpeg()
        return True

    def analisar(self, direto=False, so=None):
        if self.rodando:
            return
        alvo = [so] if so is not None else list(self.videos)
        if not alvo:
            messagebox.showinfo(APP_NAME, "Adicione pelo menos um vídeo primeiro.")
            return
        if self._precisa_ffmpeg():
            return
        n, d = int(self.stepper.valor), int(self.seg.valor)
        self._salvar_cfg()
        self.fase = "analise"
        self._set_rodando(True)
        self.barra.definir(0, True)
        self.cancelar_ev.clear()
        self._log("--- analisando ---")
        threading.Thread(target=self._worker_analise, args=(alvo, n, d, direto), daemon=True).start()

    def _worker_analise(self, alvo, n, d, direto):
        cortes.definir_log(lambda s: self.fila.put(("log", s)))

        def checar():
            if self.cancelar_ev.is_set():
                raise cortes.Cancelado()

        try:
            res = []
            for vi, v in enumerate(alvo):
                checar()

                def prog(frac, vi=vi, v=v):
                    self.fila.put(("prog", (vi + frac) / len(alvo),
                                   f"Analisando {curto(v.name, 40)}...  {int(frac * 100)}%"))

                an = cortes.analisar(v, prog, checar, cache_analises_dir())
                sug = cortes.sugerir(an, n, d)
                an["curva"] = cortes.curva_resumo(an["score"], 240)
                nota = " (análise já estava em cache)" if an["cache"] else ""
                self.fila.put(("log", f"  {v.name}: {cortes.fmt_t(an['dur'])} -> {len(sug)} sugestões{nota}"))
                res.append((v, an, sug))
            self.fila.put(("analise_ok", res, direto))
        except cortes.Cancelado:
            self.fila.put(("cancelado",))
        except cortes.ErroCortes as e:
            self.fila.put(("erro", str(e)))
        except Exception as e:
            self.fila.put(("log", traceback.format_exc()))
            self.fila.put(("erro", f"Algo deu errado: {type(e).__name__}: {e}"))

    def _analise_pronta(self, res, direto):
        self._set_rodando(False)
        vids = {v for v, _an, _s in res}
        self.itens = [it for it in self.itens if it["video"] not in vids]
        for v, an, sug in res:
            self.analises[v] = an
            for c in sug:
                self.itens.append(dict(video=v, ini=c["ini"], fim=c["fim"], nota=c["nota"], ativo=True))
        self._ordenar_itens()
        self.sel = 0
        self._linha_video = None
        self.liberado = max(self.liberado, 1)
        self.barra.definir(1, True)
        self._ir_passo(1, forcar=True)
        if direto:
            self.renderizar()

    # ======================================================================
    # Momentos (etapa 2)
    # ======================================================================
    def _ordenar_itens(self):
        ordem = {v: k for k, v in enumerate(self.videos)}
        self.itens.sort(key=lambda it: (ordem.get(it["video"], 999), it["ini"]))

    def _pos(self, it):
        for k, x in enumerate(self.itens):
            if x is it:
                return k
        return -1

    def _numeros(self):
        """Numero de cada momento dentro do SEU video (na ordem do tempo)."""
        cont, nums = {}, []
        for it in self.itens:
            cont[it["video"]] = cont.get(it["video"], 0) + 1
            nums.append(cont[it["video"]])
        return nums

    def _texto_item(self, k, it, num, multi, nota_max):
        marca = "●" if it["ativo"] else "○"
        forca = max(0, min(5, int(round(it["nota"] / nota_max * 5))))
        barra = "█" * forca + "░" * (5 - forca)
        txt = (f" {marca}  {num:02d}   {cortes.fmt_t(it['ini']):>7} → {cortes.fmt_t(it['fim']):<7}"
               f"  {barra}  {int(round(it['nota'] * 100)):>3}")
        if multi:
            txt += f"   {curto(it['video'].name, 24)}"
        return txt

    def _refrescar_momentos(self, sel=None):
        if sel is not None:
            self.sel = sel
        self.sel = min(self.sel, len(self.itens) - 1)
        multi = len({it["video"] for it in self.itens}) > 1
        nums = self._numeros()
        nota_max = max([it["nota"] for it in self.itens] + [0.01])
        self.lista_m.delete(0, "end")
        for k, it in enumerate(self.itens):
            self.lista_m.insert("end", self._texto_item(k, it, nums[k], multi, nota_max))
        if 0 <= self.sel < len(self.itens):
            self.lista_m.selection_set(self.sel)
            self.lista_m.see(self.sel)
        ativos = [it for it in self.itens if it["ativo"]]
        seg = sum(it["fim"] - it["ini"] for it in ativos)
        self.lbl_resumo_m.configure(
            text=f"{len(ativos)} de {len(self.itens)} marcados · {cortes.fmt_dur(seg)} de vídeo final")
        self._atualizar_linha()
        self._atualizar_botoes()
        self._atualizar_resumo()
        self._pedir_quadro()

    def _video_da_linha(self):
        if 0 <= self.sel < len(self.itens):
            return self.itens[self.sel]["video"]
        return self.itens[0]["video"] if self.itens else None

    def _idxs_video(self, v):
        return [k for k, it in enumerate(self.itens) if it["video"] == v]

    def _atualizar_linha(self):
        v = self._video_da_linha()
        if v is None or v not in self.analises:
            self.linha.definir([], 1, [], -1)
            self.lbl_video_m.configure(text="")
            self._linha_video = None
            return
        idxs = self._idxs_video(v)
        cortes_v = [(self.itens[k]["ini"], self.itens[k]["fim"], self.itens[k]["ativo"]) for k in idxs]
        sel_rel = idxs.index(self.sel) if self.sel in idxs else -1
        an = self.analises[v]
        if v != self._linha_video:
            self._linha_video = v
            self.linha.definir(an["curva"], an["dur"], cortes_v, sel_rel)
        else:
            self.linha.atualizar(cortes_v, sel_rel)
        self.lbl_video_m.configure(text=f"{curto(v.name, 60)}   ·   {cortes.fmt_t(an['dur'])}")

    def _selecionar(self, k):
        if not (0 <= k < len(self.itens)):
            return
        self.sel = k
        self.lista_m.selection_clear(0, "end")
        self.lista_m.selection_set(k)
        self.lista_m.see(k)
        self._atualizar_linha()
        self._pedir_quadro()

    def _lista_selecionou(self, _e=None):
        cur = self.lista_m.curselection()
        if cur and cur[0] != self.sel:
            self.sel = cur[0]
            self._atualizar_linha()
            self._pedir_quadro()

    def _tl_selecionar(self, k_rel):
        idxs = self._idxs_video(self._linha_video)
        if 0 <= k_rel < len(idxs):
            self._selecionar(idxs[k_rel])

    def _tl_adicionar(self, t):
        v = self._linha_video
        if v is None or v not in self.analises:
            return
        an = self.analises[v]
        tam = float(self.seg.valor)
        ini = min(max(t - tam / 2.0, 0.0), max(0.0, an["dur"] - tam))
        fim = min(an["dur"], ini + tam)
        novo = dict(video=v, ini=ini, fim=fim, nota=cortes.nota_trecho(an["score"], ini, fim), ativo=True)
        self.itens.append(novo)
        self._ordenar_itens()
        self._refrescar_momentos(self._pos(novo))

    def _alternar_sel(self):
        if 0 <= self.sel < len(self.itens):
            it = self.itens[self.sel]
            it["ativo"] = not it["ativo"]
            self._refrescar_momentos()

    def _marcar_todos(self, sim):
        for it in self.itens:
            it["ativo"] = bool(sim)
        self._refrescar_momentos()

    def _remover_momento(self):
        if 0 <= self.sel < len(self.itens):
            del self.itens[self.sel]
            self._refrescar_momentos(min(self.sel, len(self.itens) - 1))

    def _mover(self, delta):
        if not (0 <= self.sel < len(self.itens)):
            return
        it = self.itens[self.sel]
        an = self.analises[it["video"]]
        tam = it["fim"] - it["ini"]
        ini = min(max(it["ini"] + delta, 0.0), max(0.0, an["dur"] - tam))
        it["ini"], it["fim"] = ini, ini + tam
        it["nota"] = cortes.nota_trecho(an["score"], it["ini"], it["fim"])
        self._ordenar_itens()
        self._refrescar_momentos(self._pos(it))

    def _copiar_minutagens(self):
        ativos = [it for it in self.itens if it["ativo"]] or list(self.itens)
        if not ativos:
            return
        nums = {id(it): n for it, n in zip(self.itens, self._numeros())}
        linhas, ultimo = [], None
        for it in ativos:
            if it["video"] != ultimo:
                if linhas:
                    linhas.append("")
                linhas.append(it["video"].name)
                ultimo = it["video"]
            linhas.append(f"{nums[id(it)]:02d}  {cortes.fmt_t(it['ini'])} - {cortes.fmt_t(it['fim'])}")
        self._copiar("\n".join(linhas), "Minutagens copiadas para a área de transferência.")

    def _copiar(self, texto, aviso):
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(texto)
            self.var_status.set(aviso)
        except Exception:
            pass

    # ---------------- previa (quadro real do corte) ----------------
    def _pedir_quadro(self):
        if self.rodando:
            return
        if self.passo == 1 and 0 <= self.sel < len(self.itens):
            it = self.itens[self.sel]
            video, t = it["video"], it["ini"] + (it["fim"] - it["ini"]) * 0.35
        elif self.passo == 2 and 0 <= self.pub_sel < len(self.prontos):
            p = self.prontos[self.pub_sel]
            video, t = p["arquivo"], (p["fim"] - p["ini"]) * 0.35
        else:
            return
        chave = (str(video), int(t))
        self._thumb_chave = chave
        if chave in self._thumb_cache:
            self.previa.mostrar_quadro(*self._thumb_cache[chave])
            return
        if self._thumb_job is not None:
            self.root.after_cancel(self._thumb_job)
        self._thumb_job = self.root.after(250, lambda: self._iniciar_quadro(chave, video, t))

    def _iniciar_quadro(self, chave, video, t):
        self._thumb_job = None
        if self.rodando or chave != self._thumb_chave or not cortes.ffmpeg_disponivel():
            return

        def run():
            try:
                rgb = cortes.miniatura(video, t, self.previa.fw)
                self.fila.put(("quadro", chave, rgb, cortes.fmt_t(t)))
            except Exception:
                pass
        threading.Thread(target=run, daemon=True).start()

    # ======================================================================
    # Renderizacao (etapa 2 -> 3)
    # ======================================================================
    def renderizar(self):
        if self.rodando:
            return
        ativos = [it for it in self.itens if it["ativo"]]
        if not ativos:
            messagebox.showinfo(APP_NAME, "Marque pelo menos um momento para renderizar.")
            return
        if self._precisa_ffmpeg():
            return
        nums = {id(it): n for it, n in zip(self.itens, self._numeros())}
        trabalhos = [dict(video=it["video"], idx=nums[id(it)], ini=it["ini"], fim=it["fim"], nota=it["nota"],
                          score=self.analises.get(it["video"], {}).get("score"))
                     for it in ativos]
        args = SimpleNamespace(qualidade=self.seg_q.valor, nvenc=bool(self.sw.valor),
                               estilo=self.seg_estilo.valor, visual=self.seg_visual.valor,
                               tela_cheia=bool(self.seg_enq.valor), musica=self.musica, frases=self._frases())
        self._salvar_cfg()
        self.fase = "render"
        self._set_rodando(True)
        self.barra.definir(0, True)
        self.cancelar_ev.clear()
        self._log(f"--- renderizando {len(trabalhos)} cortes ({args.qualidade}, estilo {args.estilo}) ---")
        threading.Thread(target=self._worker_render, args=(trabalhos, args, Path(self.pasta_saida)),
                         daemon=True).start()

    def _worker_render(self, trabalhos, args, pasta):
        cortes.definir_log(lambda s: self.fila.put(("log", s)))

        def checar():
            if self.cancelar_ev.is_set():
                raise cortes.Cancelado()

        try:
            prontos = cortes.renderizar_lista(
                trabalhos, pasta, args, lambda f, t: self.fila.put(("prog", f, t)), checar)
            self.fila.put(("render_ok", prontos))
        except cortes.Cancelado:
            self.fila.put(("cancelado",))
        except cortes.ErroCortes as e:
            self.fila.put(("erro", str(e)))
        except Exception as e:
            self.fila.put(("log", traceback.format_exc()))
            self.fila.put(("erro", f"Algo deu errado: {type(e).__name__}: {e}"))

    def _render_pronto(self, prontos):
        self._set_rodando(False)
        self.prontos = prontos
        self.pub_sel = 0 if prontos else -1
        self.pub_var = {}
        self.liberado = 2
        self.barra.definir(1, True)
        self._log(f"Cortes em: {self.pasta_saida}")
        self._ir_passo(2, forcar=True)
        self.var_status.set(f"Pronto! {plural(len(prontos), 'corte salvo', 'cortes salvos')}.")
        self.p_dock.borda(V.MINT_HI)
        self.root.after(1600, lambda: self.p_dock.borda(V.LINHA))

    # ======================================================================
    # Publicacao (etapa 3)
    # ======================================================================
    def _entrar_publicar(self):
        self.lista_p.delete(0, "end")
        for p in self.prontos:
            self.lista_p.insert("end", f" {p['idx']:02d}  {cortes.fmt_t(p['ini'])} → {cortes.fmt_t(p['fim'])}")
        if self.prontos:
            self.pub_sel = min(max(self.pub_sel, 0), len(self.prontos) - 1)
            self.lista_p.selection_set(self.pub_sel)
        self.lbl_resumo_p.configure(text=plural(len(self.prontos), "corte pronto", "cortes prontos"))
        self._pub_preencher()
        self._pedir_quadro()

    def _pub_lista_selecionou(self, _e=None):
        cur = self.lista_p.curselection()
        if cur and cur[0] != self.pub_sel:
            self.pub_sel = cur[0]
            self._pub_preencher()
            self._pedir_quadro()

    def _pub_agendar(self):
        if self._pub_job is not None:
            self.root.after_cancel(self._pub_job)
        self._pub_job = self.root.after(400, self._pub_preencher)

    def _pub_trocar_plat(self, v):
        self.pub_plat = v
        self._pub_preencher()

    def _pub_corte(self, p):
        return dict(video=Path(p["video"]).name, idx=p["idx"], ini=p["ini"], fim=p["fim"], nota=p["nota"])

    def _pub_sugestao(self, p):
        var = self.pub_var.get(str(p["arquivo"]), 0)
        return publicar.sugerir(self.var_jogo.get(), self.seg_tom.valor, self._pub_corte(p), var)

    def _pub_preencher(self):
        self._pub_job = None
        self.txt_pub.delete("1.0", "end")
        self.var_titulo.set("")
        shorts = (self.pub_plat == "shorts")
        if shorts:
            self.f_titulo.pack(fill="x", before=self.txt_pub)
        else:
            self.f_titulo.pack_forget()
        self.btn_copiar_t.ativar(shorts)  # titulo separado so existe no Shorts
        if not (0 <= self.pub_sel < len(self.prontos)):
            self._pub_contador()
            return
        s = self.pub_sug = self._pub_sugestao(self.prontos[self.pub_sel])
        if shorts:
            self.var_titulo.set(s["shorts"]["titulo"])
            self.txt_pub.insert("1.0", s["shorts"]["descricao"])
        else:
            self.txt_pub.insert("1.0", s[self.pub_plat])
        self._pub_contador()

    def _pub_contador(self):
        if self.pub_plat == "shorts":
            n = len(self.var_titulo.get())
            self.lbl_cont_t.configure(text=f"{n}/{publicar.LIM_TITULO_SHORTS}",
                                      fg=V.CORAL if n > publicar.LIM_TITULO_SHORTS else V.SUB)
            self.lbl_cont.configure(text="No feed do Shorts só aparecem ~40 caracteres do título: "
                                         "as primeiras palavras importam.", fg=V.SUB)
        else:
            n = len(self.txt_pub.get("1.0", "end-1c"))
            self.lbl_cont.configure(text=f"{n}/{publicar.LIM_LEGENDA}  (as hashtags contam no limite)",
                                    fg=V.CORAL if n > publicar.LIM_LEGENDA else V.SUB)

    def _pub_copiar_titulo(self):
        self._copiar(self.var_titulo.get(), "Título copiado.")

    def _pub_copiar_texto(self):
        self._copiar(self.txt_pub.get("1.0", "end-1c"), "Texto copiado.")

    def _pub_outra(self):
        if 0 <= self.pub_sel < len(self.prontos):
            k = str(self.prontos[self.pub_sel]["arquivo"])
            self.pub_var[k] = self.pub_var.get(k, 0) + 1
            self._pub_preencher()

    def _salvar_textos(self):
        if not self.prontos:
            return
        itens = [(Path(p["arquivo"]).name, f"{cortes.fmt_t(p['ini'])}-{cortes.fmt_t(p['fim'])}",
                  self._pub_sugestao(p)) for p in self.prontos]
        try:
            destino = publicar.salvar_publicacao(self.pasta_saida, itens)
        except OSError as e:
            messagebox.showerror(APP_NAME, f"Não consegui salvar o arquivo: {e}")
            return
        self._salvar_cfg()
        self.var_status.set(f"Textos salvos em {destino.name}.")
        self._log(f"Textos salvos: {destino}")
        if messagebox.askyesno(APP_NAME, f"Textos salvos em:\n{destino}\n\nAbrir a pasta agora?"):
            self._abrir(self.pasta_saida)

    # ======================================================================
    # Execucao em segundo plano
    # ======================================================================
    def _salvar_cfg(self):
        self.cfg.update(n=int(self.stepper.valor), dur=int(self.seg.valor), nvenc=bool(self.sw.valor),
                        saida=str(self.pasta_saida), qualidade=self.seg_q.valor, anim=bool(V.ANIM.ligado),
                        jogo=self.var_jogo.get().strip(), tom=self.seg_tom.valor,
                        estilo=self.seg_estilo.valor, visual=self.seg_visual.valor,
                        tela_cheia=bool(self.seg_enq.valor), musica=self.musica,
                        frases=self.var_frases.get().strip())
        salvar_config(self.cfg)

    def cancelar(self):
        if self.rodando:
            self.cancelar_ev.set()
            self.var_status.set("Cancelando...")

    def _baixar_ffmpeg(self):
        self.fase = "link"
        self._set_rodando(True)
        self.btn_cancelar.ativar(False)
        self.var_status.set("Baixando o FFmpeg (só na primeira vez)...")
        self.barra.definir(0, True)

        def run():
            try:
                baixar_ffmpeg(lambda frac, feito: self.fila.put(("dl", frac, feito)))
                self.fila.put(("dl_ok",))
            except Exception as e:
                self.fila.put(("dl_erro", str(e)))
        threading.Thread(target=run, daemon=True).start()

    def _poll(self):
        try:
            while True:
                item = self.fila.get_nowait()
                tipo = item[0]
                if tipo == "log":
                    self._log(item[1])
                elif tipo == "prog":
                    self.barra.definir(item[1])
                    self.var_status.set(item[2])
                elif tipo == "st":
                    if item[1] is not None:
                        self.barra.definir(item[1])
                    self.var_status.set(item[2])
                elif tipo == "link_ok":
                    self._link_pronto(item[1], item[2])
                elif tipo == "analise_ok":
                    self._analise_pronta(item[1], item[2])
                elif tipo == "render_ok":
                    self._render_pronto(item[1])
                elif tipo == "quadro":
                    self._quadro_pronto(item[1], item[2], item[3])
                elif tipo == "dl":
                    if item[1] is not None:
                        self.barra.definir(item[1])
                    self.var_status.set(f"Baixando o FFmpeg... {item[2] / 1048576:.0f} MB")
                elif tipo == "dl_ok":
                    self._set_rodando(False)
                    self.barra.definir(0, True)
                    self.var_status.set("FFmpeg instalado. Clique de novo para continuar.")
                    self._log("FFmpeg instalado.")
                elif tipo == "dl_erro":
                    self._set_rodando(False)
                    self._falha(item[1])
                elif tipo == "cancelado":
                    self._set_rodando(False)
                    self.var_status.set("Cancelado.")
                    self._log("--- cancelado ---")
                elif tipo == "erro":
                    self._set_rodando(False)
                    self._falha(item[1])
        except queue.Empty:
            pass
        self.root.after(100, self._poll)

    def _quadro_pronto(self, chave, rgb, rotulo_t):
        self._thumb_cache[chave] = (rgb, rotulo_t)
        if len(self._thumb_cache) > 40:
            self._thumb_cache.pop(next(iter(self._thumb_cache)))
        if chave == self._thumb_chave and not self.rodando:
            self.previa.mostrar_quadro(rgb, rotulo_t)

    def _falha(self, msg):
        self.var_status.set("Erro. Veja os detalhes.")
        self._log("ERRO: " + msg)
        if not self.log_visivel:
            self._alternar_log()
        messagebox.showerror(APP_NAME, msg + "\n\nOs detalhes estão na janela. Use 'Copiar log' se precisar de ajuda.")

    def _set_rodando(self, sim):
        self.rodando = sim
        if not sim:
            self.fase = None
        V.ANIM.leve = bool(sim)
        self.barra.ativar(sim)
        self.previa.ocupado(sim)
        self.btn_baixar.ativar(not sim)
        self.btn_baixar_cortar.ativar(not sim)
        self._atualizar_botoes()
        if sim:
            self.btn_sec.grid_remove()
            self.btn_cancelar.grid()
            self.btn_cancelar.ativar(True)
        else:
            self.btn_cancelar.grid_remove()
            self.btn_sec.grid()
        self.p_dock.borda(V.MINT if sim else V.LINHA)

    # ======================================================================
    # Utilidades
    # ======================================================================
    def _log(self, texto):
        self.txt_log.configure(state="normal")
        self.txt_log.insert("end", str(texto).rstrip("\n") + "\n")
        self.txt_log.see("end")
        self.txt_log.configure(state="disabled")

    def _alternar_log(self):
        self.log_visivel = not self.log_visivel
        self.fundo.itemconfigure(self._rod_det, text="Esconder detalhes" if self.log_visivel else "Mostrar detalhes")
        self._garantir_altura()
        self._agendar_layout()

    def _copiar_log(self):
        self._copiar(self.txt_log.get("1.0", "end"), "Log copiado para a área de transferência.")

    def _abrir(self, pasta):
        try:
            Path(pasta).mkdir(parents=True, exist_ok=True)
            if os.name == "nt":
                os.startfile(str(pasta))  # noqa
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(pasta)])
            else:
                subprocess.Popen(["xdg-open", str(pasta)])
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Não consegui abrir a pasta: {e}")

    def _fechar(self):
        if self.rodando and not messagebox.askyesno(APP_NAME, "Ainda está processando. Fechar mesmo assim?"):
            return
        try:
            self._salvar_cfg()
        except Exception:
            pass
        self.cancelar_ev.set()
        baixador.parar()
        self.root.destroy()


def main():
    try:  # texto nitido em telas de alta densidade (Windows)
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    try:  # a barra de tarefas mostra o icone do app (e nao o do Python)
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("CortesLauncher.App")
    except Exception:
        pass
    preparar_path()
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception:  # o app abre sem console: se falhar ao abrir, mostra o motivo e salva um arquivo
        import traceback
        txt = traceback.format_exc()
        try:
            (dados_dir() / "erro.txt").write_text(txt, encoding="utf-8")
        except Exception:
            pass
        try:
            r = tk.Tk()
            r.withdraw()
            messagebox.showerror(APP_NAME, "O app não conseguiu abrir.\n\n" + txt[-600:] +
                                 f"\n\nDetalhes salvos em:\n{dados_dir() / 'erro.txt'}")
        except Exception:
            pass
        sys.exit(1)
